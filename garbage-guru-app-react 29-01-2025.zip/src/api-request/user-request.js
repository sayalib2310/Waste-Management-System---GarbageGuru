import axios from "axios";

const base_url = process.env.REACT_APP_API_BASE_URL;

// User Registration
export async function registerUser(userData) {
  try {
    const response = await axios.post(`${base_url}/users`, userData);
    return {
      status: response.data.status === "success",
      data: response.data.data,
    };
  } catch (error) {
    console.error("Error registering user:", error.response.data.message);
    return {
      status: false,
      message:
        error.response?.data != null ? error.response.data.message : error,
    };
  }
}

// User Login
export async function loginUser(loginData) {
  try {
    const response = await axios.post(`${base_url}/users/login`, loginData);
    return {
      status: response.data.status === "success",
      data: response.data.data,
    };
  } catch (error) {
    console.error("Error logging in:", error);
    return {
      status: false,
      message:
        error.response?.data != null ? error.response.data.message : error,
      data: {},
    };
  }
}

// Get All Users List
export async function getAllUsers() {
  try {
    const response = await axios.get(`${base_url}/users`);
    return { status: true, data: response.data.data };
  } catch (error) {
    console.error("Error fetching users list:", error);
    return { status: false, message:
      error.response?.data != null ? error.response.data.message : error, data: [] };
  }
}

// Delete User by ID
export async function deleteUserById(userId) {
  try {
    const response = await axios.delete(`${base_url}/users/${userId}`);
    return {
      status: response.data.status === "success",
      data: response.data.data,
    };
  } catch (error) {
    console.error("Error deleting user:", error);
    return { status: false,  message:
      error.response?.data != null ? error.response.data.message : error, data: [] };
  }
}

// Get User by ID
export async function getUserById(userId) {
  try {
    const response = await axios.get(`${base_url}/users/${userId}`);
    return { status: true, data: response.data.data };
  } catch (error) {
    console.error("Error fetching user by ID:", error);
    return { status: false,  message:
      error.response?.data != null ? error.response.data.message : error,  };
  }
}

// Update User by ID
export async function updateUserById(userId, userData) {
  try {
    const response = await axios.put(`${base_url}/users/${userId}`, userData);
    return {
      status: response.data.status === "success",
      data: response.data.data,
    };
  } catch (error) {
    console.error("Error updating user:", error);
    return { status: false,  message:
      error.response?.data != null ? error.response.data.message : error, data: [] };
  }
}

// Get Address, Category, and Status List
export async function getAddressCategoryStatusList() {
  try {
    const response = await axios.get(
      `${base_url}/users/address-category-status`
    );
    return { status: true, data: response.data.data };
  } catch (error) {
    console.error("Error fetching address-category-status list:", error);
    return { status: false,  message:
      error.response?.data != null ? error.response.data.message : error, data: {} };
  }
}
export async function getVolunteerByVolunteerId(volunteerId) {
  try {
    const response = await axios.get(
      `${base_url}/users/volunteer/${volunteerId}`
    );
    return { status: true, data: response.data.data };
  } catch (error) {
    console.error("Error fetching address-category-status list:", error);
    return { status: false, message:
      error.response?.data != null ? error.response.data.message : error, data: {} };
  }
}

// Register as Volunteer
export async function registerAsVolunteer(volunteerData) {
  try {
    const response = await axios.post(
      `${base_url}/users/volunteer`,
      volunteerData
    );
    return {
      status: response.data.status === "success",
      data: response.data.data,
    };
  } catch (error) {
    console.error("Error registering as volunteer:", error);
    return { status: false,  message:
      error.response?.data != null ? error.response.data.message : error, };
  }
}

// Create Complaint
export async function createComplaint(complaintData) {
  try {
    const response = await axios.post(
      `${base_url}/users/complaints/create`,
      complaintData
    );
    return {
      status: response.data.status === "success",
      data: response.data.data,
    };
  } catch (error) {
    console.error("Error creating complaint:", error);
    return { status: false,  message:
      error.response?.data != null ? error.response.data.message : error, data: {} };
  }
}

// Get Complaints by User ID
export async function getComplaintsByUserId(userId) {
  try {
    const response = await axios.get(`${base_url}/users/${userId}/complaints`);
    return { status: true, data: response.data.data };
  } catch (error) {
    console.error("Error fetching complaints by user ID:", error);
    return { status: false, message:
      error.response?.data != null ? error.response.data.message : error, data: [] };
  }
}
