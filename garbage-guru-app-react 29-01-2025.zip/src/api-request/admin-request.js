import axios from "axios";

const base_url = process.env.REACT_APP_API_BASE_URL;

// Create Event
export async function createEvent(eventData) {
  try {
    const response = await axios.post(`${base_url}/admin/event`, eventData);
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error("Error creating event:", error);
    return { status: false, message: "Error creating event", error };
  }
}

// Delete Event
export async function deleteEvent(eventId) {
  try {
    const response = await axios.delete(`${base_url}/admin/event/${eventId}`);
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error(`Error deleting event with ID ${eventId}:`, error);
    return { status: false, message: `Error deleting event with ID ${eventId}`, error };
  }
}

// Update Event
export async function updateEvent(eventId, eventData) {
  try {
    const response = await axios.put(`${base_url}/admin/event/${eventId}`, eventData);
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error(`Error updating event with ID ${eventId}:`, error);
    return { status: false, message: `Error updating event with ID ${eventId}`, error };
  }
}

// Get List of Volunteers
export async function getVolunteers() {
  try {
    const response = await axios.get(`${base_url}/admin/volunteers`);
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error("Error fetching volunteers:", error);
    return { status: false, message: "Error fetching volunteers "+ error.response.data.message,data:[] };
  }
}

// Get List of Event Enrollments by Event ID
export async function getEventEnrollments(eventId) {
  try {
    const response = await axios.get(`${base_url}/admin/event/${eventId}/enrollments`);
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error(`Error fetching enrollments for event ID ${eventId}:`, error);
    return { status: false, message: `Error fetching enrollments for event ID ${eventId} ` + error.response.data.message,data:[] };
  }
}

// Delete Volunteer
export async function deleteVolunteer(volunteerId) {
  try {
    const response = await axios.delete(`${base_url}/admin/volunteers/${volunteerId}`);
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error(`Error deleting volunteer with ID ${volunteerId}:`, error);
    return { status: false, message: `Error deleting volunteer with ID ${volunteerId}`, error };
  }
}

// Get List of Complaints
export async function getComplaints() {
  try {
    const response = await axios.get(`${base_url}/admin/complaints`);
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error("Error fetching complaints:", error);
    return { status: false, message: "Error fetching complaints "+ error.response.data.message,data:[] };
  }
}

// Update Complaint Status
export async function updateComplaintStatus(complaintId, status) {
  try {
    const response = await axios.put(
      `${base_url}/admin/complaints/${complaintId}/status`,
      null,
      { params: { status } }
    );
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error(`Error updating status of complaint ID ${complaintId}:`, error);
    return { status: false, message: `Error updating status of complaint ID ${complaintId}`, error };
  }
}

// Get Complaint by ID
export async function getComplaintById(complaintId) {
  try {
    const response = await axios.get(`${base_url}/admin/complaints/${complaintId}`);
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error(`Error fetching complaint with ID ${complaintId}:`, error);
    return { status: false, message: `Error fetching complaint with ID ${complaintId}`, error };
  }
}

// Delete Complaint
export async function deleteComplaint(complaintId) {
  try {
    const response = await axios.delete(`${base_url}/admin/complaints/${complaintId}`);
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error(`Error deleting complaint with ID ${complaintId}:`, error);
    return { status: false, message: `Error deleting complaint with ID ${complaintId}`, error };
  }
}
