import axios from "axios";

const base_url = process.env.REACT_APP_API_BASE_URL;

// Get All Events
export async function getAllEvents(volunteerId, eventId) {
  try {
    const response = await axios.get(`${base_url}/event`, {
      params: { volunteerId, eventId },
    });
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error("Error fetching all events:", error);
    return { status: false, message: "Error fetching all events "+ error.response.data.message };
  }
}

// Get Events by Volunteer ID
export async function getEventsByVolunteerId(volunteerId) {
  try {
    const response = await axios.get(`${base_url}/event/volunteer/${volunteerId}`);
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error(`Error fetching events for volunteer ID ${volunteerId}:`, error);
    return { status: false, message: `Error fetching events for volunteer ID ${volunteerId} `+error.response.data.message,data:[] };
  }
}

// Enroll in Event
export async function enrollInEvent(volunteerId, eventId) {
  try {
    const response = await axios.post(`${base_url}/event`, null, {
      params: { volunteerId, eventId },
    });
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error(`Error enrolling volunteer ID ${volunteerId} in event ID ${eventId}:`, error);
    return { status: false, message: `Error enrolling volunteer ID ${volunteerId} in event ID ${eventId}`, error };
  }
}
export async function removeEnrollInEvent(volunteerId, eventId) {
  try {
    const response = await axios.delete(`${base_url}/event/remove/${eventId}/${volunteerId}`);
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error(`Error enrolling delete volunteer ID ${volunteerId} in event ID ${eventId}:`, error);
    return { status: false, message: `Error delete enrolling volunteer ID ${volunteerId} in event ID ${eventId}`, error };
  }
}
