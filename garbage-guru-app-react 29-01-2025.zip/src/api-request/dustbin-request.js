import axios from "axios";

const base_url = process.env.REACT_APP_API_BASE_URL;
// Get Dustbins List
export async function getDustbins() {
  try {
    const response = await axios.get(`${base_url}/dustbins`);
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error("Error fetching dustbins list:", error);
    return { status: false, message: "Error fetching dustbins list "+ error.response.data.message, };
  }
}

// Create Dustbin
export async function createDustbin(dustbinData) {
  try {
    const response = await axios.post(`${base_url}/dustbins`, dustbinData);
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error("Error creating dustbin:", error);
    return { status: false, message: error.response.data.message };
  }
}

// Get Dustbin by ID
export async function getDustbinById(dustbinId) {
  try {
    const response = await axios.get(`${base_url}/dustbins/${dustbinId}`);
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error(`Error fetching dustbin with ID ${dustbinId}:`, error);
    return { status: false, message: `Error fetching dustbin with ID ${dustbinId}`, error };
  }
}

// Delete Dustbin by ID
export async function deleteDustbinById(dustbinId) {
  try {
    const response = await axios.delete(`${base_url}/dustbins/${dustbinId}`);
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error(`Error deleting dustbin with ID ${dustbinId}:`, error);
    return { status: false, message: `Error deleting dustbin with ID ${dustbinId}`, error };
  }
}

// Update Dustbin by ID
export async function updateDustbinById(dustbinId, dustbinData) {
  try {
    const response = await axios.put(`${base_url}/dustbins/${dustbinId}`, dustbinData);
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error(`Error updating dustbin with ID ${dustbinId}:`, error);
    return { status: false, message: `Error updating dustbin with ID ${dustbinId} \n ${error.response.data.message} `, error };
  }
}

// Get Dustbins by Area ID
export async function getDustbinsByAreaId(areaId) {
  try {
    const response = await axios.get(`${base_url}/dustbins/area/${areaId}`);
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error(`Error fetching dustbins for area ID ${areaId}:`, error);
    return { status: false, message: `Error fetching dustbins for area ID ${areaId} `+ error.response.data.message,data:[]};
  }
}

// Get Dustbins by Category ID
export async function getDustbinsByCategoryId(categoryId) {
  try {
    const response = await axios.get(`${base_url}/dustbins/category/${categoryId}`);
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error(`Error fetching dustbins for category ID ${categoryId}:`, error);
    return { status: false, message: `Error fetching dustbins for category ID ${categoryId}`, error };
  }
}

// Get Dustbin by Dustbin Number
export async function getDustbinByNumber(dustbinNumber) {
  try {
    const response = await axios.get(`${base_url}/dustbins/number/${dustbinNumber}`);
    return {
      status: response.data.status === "success",
      message: response.data.message,
      data: response.data.data,
    };
  } catch (error) {
    console.error(`Error fetching dustbin with number ${dustbinNumber}:`, error);
    return { status: false, message: `Error fetching dustbin with number ${dustbinNumber}`, error };
  }
}
