import { Link, Outlet, } from "react-router-dom";
import Navbar from "./Navbar";

const Layout = () => {
    return (
        <>
            <Navbar />

            <main className=" overflow-scroll bg-info-subtle main-container"  id="container">

                <Outlet />
                <footer className="py-3 my-4">
                    <ul className="nav justify-content-center border-top border-secondary pb-3 mb-3">
                        <li className="nav-item"><Link tp="/" className="nav-link px-2 text-body-secondary">Home</Link></li>
                        <li className="nav-item"><Link tp="/" className="nav-link px-2 text-body-secondary">Contact</Link></li>
                        <li className="nav-item"><Link tp="/" className="nav-link px-2 text-body-secondary">About Us</Link></li>
                        <li className="nav-item"><Link tp="/" className="nav-link px-2 text-body-secondary">Blogs</Link></li>
                        <li className="nav-item"><Link tp="/" className="nav-link px-2 text-body-secondary">Events</Link></li>
                    </ul>
                    <p className="text-center text-body-secondary">
                       
                            &copy; 2025 Garbage Guru. All rights reserved. | Designed for a cleaner tomorrow.
                        
                    </p>
                </footer>
            </main>

        </>
    )
};

export default Layout;