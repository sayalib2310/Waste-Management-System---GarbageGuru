import React, { useEffect, useState } from 'react'

export default function BlogsPage() {
  useEffect(() => {
    document.getElementById("container").scrollTo(0, 0);

}, []);
  const [blogs, setBlogs] = useState([
    {
      id: 1,
      title: "The Importance of Waste Management",
      description: "Learn why proper waste management is crucial for a sustainable future.",
      author: "John Doe",
      date: "January 15, 2025",
    },
    {
      id: 2,
      title: "Recycling Tips for Beginners",
      description: "Simple steps you can take to start recycling at home and in your community.",
      author: "Jane Smith",
      date: "January 20, 2025",
    },
    {
      id: 3,
      title: "Innovative Ways to Reduce Plastic Use",
      description: "Discover creative methods to minimize plastic usage in your daily life.",
      author: "Emily Johnson",
      date: "January 25, 2025",
    },
  ]);

  return (
    <div className="container mt-4">
      <h2 className="text-center mb-4">Our Blogs</h2>
      <div className="row g-4">
        {blogs.map((blog) => (
          <div className="col-md-6 col-lg-4" key={blog.id}>
            <div className="card shadow-sm">
              <div className="card-body">
                <h5 className="card-title">{blog.title}</h5>
                <p className="card-text text-muted">{blog.description}</p>
                <p className="card-text">
                  <small className="text-muted">
                    By {blog.author} | {blog.date}
                  </small>
                </p>
                <button className="btn btn-primary  mt-5 w-100">Read More</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
