
import React, { useEffect } from 'react'

export default function ContactPage() {

  useEffect(() => {
    document.getElementById("container").scrollTo(0, 0);

}, []);
  return (
    <div className="container my-5">
    <h2 className="text-center mb-5 fw-bold">Contact Us</h2>
  
    <div className="row g-4">
      {/* Section 1: Address */}
      <div className="col-md-6 col-lg-3">
        <div className="card shadow-lg h-100 text-center border-0">
          <div className="card-body">
            <div className="icon-circle bg-danger text-white mx-auto mb-4">
              <i className="bi bi-geo-alt-fill fs-1"></i>
            </div>
            <h5 className="card-title fw-semibold">Our Address</h5>
            <p className="card-text text-muted">
              123 Green Street,<br />
              Eco City, 456789<br />
              Country
            </p>
          </div>
        </div>
      </div>
  
      {/* Section 2: Phone */}
      <div className="col-md-6 col-lg-3">
        <div className="card shadow-lg h-100 text-center border-0">
          <div className="card-body">
            <div className="icon-circle bg-success text-white mx-auto mb-4">
              <i className="bi bi-telephone-fill fs-1"></i>
            </div>
            <h5 className="card-title fw-semibold">Call Us</h5>
            <p className="card-text text-muted">
              Phone: +123 456 7890<br />
              Toll-Free: 1800-123-456
            </p>
          </div>
        </div>
      </div>
  
      {/* Section 3: Email */}
      <div className="col-md-6 col-lg-3">
        <div className="card shadow-lg h-100 text-center border-0">
          <div className="card-body">
            <div className="icon-circle bg-primary text-white mx-auto mb-4">
              <i className="bi bi-envelope-fill fs-1"></i>
            </div>
            <h5 className="card-title fw-semibold">Email Us</h5>
            <p className="card-text text-muted">
              support@garbageguru.com<br />
              info@garbageguru.com
            </p>
          </div>
        </div>
      </div>
  
      {/* Section 4: Social Media */}
      <div className="col-md-6 col-lg-3">
        <div className="card shadow-lg h-100 text-center border-0">
          <div className="card-body">
            <div className="icon-circle bg-info text-white mx-auto mb-4">
              <i className="bi bi-share-fill fs-1"></i>
            </div>
            <h5 className="card-title fw-semibold">Follow Us</h5>
            <p className="card-text text-muted">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-decoration-none text-dark"
              >
                Facebook
              </a>
              <br />
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-decoration-none text-dark"
              >
                Twitter
              </a>
              <br />
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-decoration-none text-dark"
              >
                Instagram
              </a>
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  );
}
