import React, { useEffect } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { getUserById, registerAsVolunteer } from "../api-request/user-request";
import SweetAlert from "sweetalert2";
import { login } from "../redux/store";
import Swal from "sweetalert2";

export default function VolunteerRegistrationPage() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const user = useSelector((state) => state.user.userInfo);
  useEffect(() => {
    console.log(user);

    if (!user?.firstName) {
      Swal.fire(
        "Error",
        "You Not login please Login Or Register!",
        "error"
      ).then(async () => {
        navigate("/login");
        console.log(user);
      });
      return;
    }
    if (!user?.volunteer) {
      Swal.fire(
        "Error",
        "You Not register as Volunteer! <br/> For Participate in Event Register For Volunteer",
        "error"
      );
      return;
    }
    if (user?.volunteer) {
      SweetAlert.fire(
        "Error",
        "User Already register as Volunteer!",
        "error"
      ).then(async () => {
        navigate("/volunteers");
      });
    }
  }, [user, navigate]);

  const onSubmit = async (data) => {
    console.log("Form Data:", data);

    const requestData = {
      userId: user.userId,
      department: data.department,
      purpose: data.purpose,
      experience: data.experience,
    };

    const response = await registerAsVolunteer(requestData);

    console.log(response.data);
    console.log(user);

    if (response.status) {
      SweetAlert.fire(
        "Success",
        "registered as Volunteer successfully!",
        "success"
      ).then(async () => {
        // navigate("/login")
        console.log(user);
        const newUser = (await getUserById(user.userId)).data;

        dispatch(login({ ...user, ...newUser }));
      });
    } else {
      SweetAlert.fire(
        "Error",
        `Volunteer registered failed! <br/>${response.message}`,
        "error"
      );
    }
  };

  useEffect(() => {
    document.getElementById("container").scrollTo(0, 0);
  }, []);

  const departments = [
    "Environment",
    "Education",
    "Healthcare",
    "Animal Welfare",
  ];

  return (
    <div className="d-flex justify-content-center align-items-center vh-100">
      <div
        className="border p-4 rounded bg-light"
        style={{ width: "40rem", boxShadow: "0px 4px 6px rgba(0,0,0,0.1)" }}
      >
        <h3 className="text-center mb-4">Volunteer Registration</h3>
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="mb-3">
            <label htmlFor="name" className="form-label">
              Name
            </label>
            <input
              type="text"
              id="name"
              className="form-control"
              defaultValue={`${user?.firstName} ${user?.lastName}`}
              disabled={!!user?.firstName}
              {...register("name", { required: "Name is required" })}
            />
            {errors.name && (
              <small className="text-danger">{errors.name.message}</small>
            )}
          </div>
          <div className="mb-3">
            <label htmlFor="department" className="form-label">
              Department
            </label>
            <select
              id="department"
              className="form-select"
              {...register("department", {
                required: "Please select a department",
              })}
            >
              <option value="">Select Department</option>
              {departments.map((dept, index) => (
                <option key={index} value={dept}>
                  {dept}
                </option>
              ))}
            </select>
            {errors.department && (
              <small className="text-danger">{errors.department.message}</small>
            )}
          </div>
          <div className="mb-3">
            <label htmlFor="purpose" className="form-label">
              Purpose
            </label>
            <textarea
              id="purpose"
              className="form-control"
              rows="3"
              {...register("purpose", { required: "Purpose is required" })}
            ></textarea>
            {errors.purpose && (
              <small className="text-danger">{errors.purpose.message}</small>
            )}
          </div>
          <div className="mb-3">
            <label htmlFor="experience" className="form-label">
              Experience (in months)
            </label>
            <input
              type="number"
              id="experience"
              className="form-control"
              {...register("experience", {
                required: "Experience is required",
                min: { value: 0, message: "Experience cannot be negative" },
              })}
            />
            {errors.experience && (
              <small className="text-danger">{errors.experience.message}</small>
            )}
          </div>
          <div className="d-grid">
            <button type="submit" className="btn btn-primary">
              Register
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
