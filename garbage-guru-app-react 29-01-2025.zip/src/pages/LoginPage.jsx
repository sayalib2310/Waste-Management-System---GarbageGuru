import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Link, useNavigate } from "react-router-dom";
import { loginUser } from "../api-request/user-request";
import SweetAlert from "sweetalert2";
import { useDispatch } from "react-redux";
import { login } from "../redux/store";
import Swal from "sweetalert2";

export default function LoginPage() {
  const { register, handleSubmit } = useForm();
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const onSubmit = async (data) => {
    console.log("Form Data:", data);

    try {
      const response = await loginUser(data);

      console.log(response);

      if (response.status) {
        SweetAlert.fire("Success", "User Login successfully!", "success").then(
          () => {
            if (response.data.role.roleId === 2) {
              dispatch(login({ ...response.data, dashboardUrl: "/admin" }));
              navigate("/admin");
              return;
            }
            dispatch(login({ ...response.data, dashboardUrl: "/user" }));

            navigate("/user");
          }
        );
      } else {
        SweetAlert.fire(
          "Error",
          `User Login failed! <br/>${response.message}`,
          "error"
        );
      }
    } catch (error) {
      console.log(error);

      Swal.fire("Error", `User Login failed n! <br/>${error}`, "error");
    }
  };

  useEffect(() => {
    document.getElementById("container").scrollTo(0, 0);
  }, []);
  return (
    <div className="d-flex justify-content-center align-items-center mt-5">
      <div
        className="border border-1 shadow p-4 rounded border-dark-subtle bg-light "
        style={{ width: "40rem", boxShadow: "0px 4px 6px rgba(0,0,0,0.1)" }}
      >
        <h3 className="text-center mb-4">Login</h3>
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="mb-5">
            <label htmlFor="userName" className="form-label">
              Username
            </label>
            <input
              type="text"
              id="userName"
              className="form-control"
              {...register("userName", { required: true })}
              placeholder="Enter userName"
            />
          </div>
          <div className="mb-5">
            <label htmlFor="password" className="form-label">
              Password
            </label>
            <div className="input-group">
              <input
                type={showPassword ? "text" : "password"}
                id="password"
                className="form-control"
                {...register("password", { required: true })}
                placeholder="Enter password"
              />
              <button
                type="button"
                className="btn btn-outline-secondary"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? "Hide" : "Show"}
              </button>
            </div>
          </div>
          <div className="d-grid gap-4">
            <button type="submit" className="btn btn-primary">
              Login
            </button>
            <Link type="button" to="/register" className="btn btn-secondary">
              Register
            </Link>
          </div>
          <div className="text-center mt-3">
            <Link href="#" className="text-decoration-none">
              Forgot Password?
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
}
