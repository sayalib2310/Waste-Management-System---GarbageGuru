import React, { useEffect, useState } from "react";
import SweetAlert from "sweetalert2";

import { useForm } from "react-hook-form";
import {
  getAddressCategoryStatusList,
  registerUser,
} from "../api-request/user-request";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2";

export default function RegistrationPage() {
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm();

  const [areas, setAreas] = useState([]);

  const navigate = useNavigate();

  async function fetchData() {
    try {
      const response1 = await getAddressCategoryStatusList();
      if (response1.status) {
        const basicData = response1.data;

        console.log(basicData);

        setAreas(basicData.address);
      }
      else{
      Swal.fire("Error", `Network Error <br/>${response1.message}`, "error");

      }
    } catch (error) {
      console.log(error);
      Swal.fire("Error", `Network Error <br/>${error}`, "error");
    }
  }

  function transformUserObject(input) {
    return {
      firstName: input.firstName,
      lastName: input.lastName,
      userName: input.userName,
      emailId: input.emailId,
      password: input.password,
      contactNo: input.contactNo,
      aadharNo: input.aadharNo,
      address: input.address,
      roleId: 1,
      areaId: parseInt(input.area, 10),
    };
  }

  const onSubmit = async (data) => {
    const requestData = transformUserObject(data);

    const response = await registerUser(requestData);

    console.log(response.data);

    if (response.status) {
      SweetAlert.fire(
        "Success",
        "User registered successfully!",
        "success"
      ).then(() => {
        navigate("/login");
      });
    } else {
      SweetAlert.fire(
        "Error",
        `User registered failed! <br/>${response.message}`,
        "error"
      );
    }
  };

  useEffect(() => {
    document.getElementById("container").scrollTo(0, 0);
    fetchData();
  }, []);

  return (
    <div className="d-flex justify-content-center align-items-center mt-5 ">
      <div
        className="border border-1 shadow p-4 rounded  border-dark-subtle bg-light "
        style={{ width: "40rem", boxShadow: "0px 4px 6px rgba(0,0,0,0.1)" }}
      >
        <h3 className="text-center mb-4">Registration</h3>
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="row w-100  g-3 mb-5 m-1">
            <div className="col-6">
              <label htmlFor="firstName" className="form-label">
                First Name
              </label>
              <input
                type="text"
                id="firstName"
                className="form-control"
                {...register("firstName", {
                  required: "First name is required",
                })}
              />
              {errors.firstName && (
                <small className="text-danger">
                  {errors.firstName.message}
                </small>
              )}
            </div>
            <div className=" col-6">
              <label htmlFor="lastName" className="form-label">
                Last Name
              </label>
              <input
                type="text"
                id="lastName"
                className="form-control"
                {...register("lastName", { required: "Last name is required" })}
              />
              {errors.lastName && (
                <small className="text-danger">{errors.lastName.message}</small>
              )}
            </div>
            <div className="">
              <label htmlFor="userName" className="form-label">
                Username
              </label>
              <input
                type="text"
                id="userName"
                className="form-control"
                {...register("userName", { required: "Username is required" })}
              />
              {errors.userName && (
                <small className="text-danger">{errors.userName.message}</small>
              )}
            </div>
            <div className="col-12">
              <label htmlFor="emailId" className="form-label">
                Email
              </label>
              <input
                type="emailId"
                id="emailId"
                className="form-control"
                {...register("emailId", {
                  required: "Email is required",
                  pattern: {
                    value: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/,
                    message: "Invalid emailId address",
                  },
                })}
              />
              {errors.emailId && (
                <small className="text-danger">{errors.emailId.message}</small>
              )}
            </div>
            <div className="col-12">
              <label htmlFor="password" className="form-label">
                Password
              </label>
              <input
                type="password"
                id="password"
                className="form-control"
                {...register("password", {
                  required: "Password is required",
                  minLength: 6,
                })}
              />
              {errors.password && (
                <small className="text-danger">{errors.password.message}</small>
              )}
            </div>
            <div className="col-12">
              <label htmlFor="confirmPassword" className="form-label">
                Confirm Password
              </label>
              <input
                type="password"
                id="confirmPassword"
                className="form-control"
                {...register("confirmPassword", {
                  required: "Confirm Password is required",
                  validate: (value) =>
                    value === watch("password") || "Passwords do not match",
                })}
              />
              {errors.confirmPassword && (
                <small className="text-danger">
                  {errors.confirmPassword.message}
                </small>
              )}
            </div>
            <div className="col-12">
              <label htmlFor="contactNo" className="form-label">
                Contact Number
              </label>
              <input
                type="text"
                id="contactNo"
                className="form-control"
                {...register("contactNo", {
                  required: "Contact number is required",
                  pattern: {
                    value: /^[0-9]{10}$/,
                    message: "Invalid contact number",
                  },
                })}
              />
              {errors.contactNo && (
                <small className="text-danger">
                  {errors.contactNo.message}
                </small>
              )}
            </div>
            <div className="col-12">
              <label htmlFor="aadharNo" className="form-label">
                Aadhar Number
              </label>
              <input
                type="text"
                id="aadharNo"
                className="form-control"
                {...register("aadharNo", {
                  required: "Aadhar number is required",
                  pattern: {
                    value: /^[0-9]{12}$/,
                    message: "Invalid Aadhar number",
                  },
                })}
              />
              {errors.aadharNo && (
                <small className="text-danger">{errors.aadharNo.message}</small>
              )}
            </div>
            <div className="col-12">
              <label htmlFor="address" className="form-label">
                Address
              </label>
              <textarea
                id="address"
                className="form-control"
                rows="2"
                {...register("address", { required: "Address is required" })}
              ></textarea>
              {errors.address && (
                <small className="text-danger">{errors.address.message}</small>
              )}
            </div>
            <div className="col-12">
              <label htmlFor="area" className="form-label">
                Area
              </label>
              <select
                id="area"
                className="form-select"
                {...register("area", { required: "Please select an area" })}
              >
                <option value="">Select Area</option>
                {areas.map((area, index) => (
                  <option key={index} value={area.areaId}>
                    {area.areaName}
                  </option>
                ))}
              </select>
              {errors.area && (
                <small className="text-danger">{errors.area.message}</small>
              )}
            </div>
            <div className="d-grid">
              <button type="submit" className="btn btn-primary">
                Register
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
