// import React from 'react'

import { useEffect } from "react";
import { Link } from "react-router-dom";

import image1 from "../assets/06_06_2024_16_20_32_757966.webp";
import image2 from "../assets/recycle.avif";
import image3 from "../assets/volunteers-clean-garbage_176516-1174.avif";

import image4 from "../assets/simple-2d-vector-smart-digital-dustbin-vector-illustration_969863-230569.avif";
import image5 from "../assets/background-with-ecology-recycling-concept_23-2148234397.avif";
import image6 from "../assets/happy-woman-participating-in-park-clean-up-girl-is-engaged-in-plogging-illustration-with-flat-colors-and-simple-shapes-community-service-and-environme.jpg";

export default function HomePage() {

  useEffect(() => {
    document.getElementById("container").scrollTo(0, 0);

  }, []);
  return (
    <>
      <div id="myCarousel" className="carousel slide mb-6" data-bs-ride="carousel">
        <div className="carousel-indicators">
          <button
            type="button"
            data-bs-target="#myCarousel"
            data-bs-slide-to="0"
            className="active"
            aria-current="true"
            aria-label="Slide 1"
          ></button>
          <button
            type="button"
            data-bs-target="#myCarousel"
            data-bs-slide-to="1"
            aria-label="Slide 2"
          ></button>
          <button
            type="button"
            data-bs-target="#myCarousel"
            data-bs-slide-to="2"
            aria-label="Slide 3"
          ></button>
        </div>
        <div className="carousel-inner ">
          <div className="carousel-item active">
            <img
              src={image1}
              className="d-block w-100"
              alt="Smart Waste Management"
            />
            <div className="container">
              <div className="carousel-caption text-start text-black ">
                <h1>Empowering Cities with Smart Waste Management</h1>
                <p className="opacity-75">
                  At Garbage Guru, we combine technology and community to create cleaner cities.
                </p>
                <p>
                  <a className="btn btn-lg btn-primary" href="#">
                    Learn More
                  </a>
                </p>
              </div>
            </div>
          </div>
          <div className="carousel-item">
            <img
              src={image2}
              className="d-block w-100"
              alt="Recycle for a Greener Future"
            />
            <div className="container">
              <div className="carousel-caption text-black ">
                <h1>Recycle for a Greener Future</h1>
                <p>
                  Join our recycling programs and take part in saving the planet, one step at a time.
                </p>
                <p>
                  <a className="btn btn-lg btn-primary" href="#">
                    Get Involved
                  </a>
                </p>
              </div>
            </div>
          </div>
          <div className="carousel-item">
            <img
              src={image3}
              className="d-block w-100"
              alt="Community Clean-Up Drives"
            />
            <div className="container">
              <div className="carousel-caption text-black  text-end">
                <h1>Community Clean-Up Drives</h1>
                <p>
                  Be a part of our hands-on efforts to beautify your neighborhood and city.
                </p>
                <p>
                  <a className="btn btn-lg btn-primary" href="#">
                    Join Us
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
        <button
          className="carousel-control-prev"
          type="button"
          data-bs-target="#myCarousel"
          data-bs-slide="prev"
        >
          <span className="carousel-control-prev-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Previous</span>
        </button>
        <button
          className="carousel-control-next"
          type="button"
          data-bs-target="#myCarousel"
          data-bs-slide="next"
        >
          <span className="carousel-control-next-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Next</span>
        </button>
      </div>

      <div className="container marketing">
        <div className="row">
          <div className="col-lg-4 d-flex align-items-stretch">
            <div className="card shadow-sm border rounded text-center w-100">
              <img
                src={image4}
                className="bd-placeholder-img rounded-circle mx-auto mt-3 w-50"
                alt="Smart Dustbins"
              />
              <div className="card-body">
                <h2 className="fw-normal">Smart Dustbins</h2>
                <p>
                  Our smart dustbins use IoT technology to monitor garbage levels and optimize waste
                  collection schedules, ensuring cleaner streets and neighborhoods.
                </p>
                <p>
                  <a className="btn btn-secondary" href="#">
                    Learn More &raquo;
                  </a>
                </p>
              </div>
            </div>
          </div>
          <div className="col-lg-4 d-flex align-items-stretch">
            <div className="card shadow-sm border rounded text-center w-100">
              <img
                src={image5}
                className="bd-placeholder-img rounded-circle mx-auto mt-3 w-50"
                alt="Recycling Programs"
              />
              <div className="card-body">
                <h2 className="fw-normal">Recycling Programs</h2>
                <p>
                  Our initiatives promote effective recycling by providing resources, drop-off points,
                  and educational campaigns on sustainable practices.
                </p>
                <p>
                  <a className="btn btn-secondary" href="#">
                    Explore Programs &raquo;
                  </a>
                </p>
              </div>
            </div>
          </div>
          <div className="col-lg-4 d-flex align-items-stretch">
            <div className="card shadow-sm border rounded text-center w-100">
              <img
                src={image6}
                className="bd-placeholder-img rounded-circle mx-auto mt-3 w-50"
                alt="Community Engagement"
              />
              <div className="card-body">
                <h2 className="fw-normal">Community Engagement</h2>
                <p>
                  Join our community drives and workshops to raise awareness and actively participate
                  in building a cleaner environment.
                </p>
                <p>
                  <Link className="btn btn-secondary" to="volunteers">
                    Get Involved &raquo;
                  </Link>
                </p>
              </div>
            </div>
          </div>
        </div>








        <hr className="featurette-divider" />

        <div className="row featurette">
          <section className="bg-light py-5">
            <div className="container text-center">
              <h2 className="mb-4">Get Started with Garbage Guru</h2>
              <p className="mb-4">
                Join us in our mission to create a cleaner, healthier city. Explore our innovative
                Dustbin Management System to improve waste collection and disposal.
              </p>
              <a href="/dustbins" className="btn btn-primary btn-lg">
                Explore Dustbins
              </a>
            </div>
          </section>
        </div>

        <hr className="featurette-divider" />

        <section className="container my-5">
          <h2 className="text-center mb-4">Why Choose Our Dustbin Management System?</h2>
          <div className="row text-center">
            <div className="col-md-4 mb-4">
              <i className="bi bi-geo-alt-fill fs-1 text-success"></i>
              <h4 className="mt-3">Track Dustbins by Area</h4>
              <p>Easily locate and manage dustbins across different areas in the city.</p>
            </div>
            <div className="col-md-4 mb-4">
              <i className="bi bi-bar-chart-fill fs-1 text-info"></i>
              <h4 className="mt-3">Monitor Garbage Levels</h4>
              <p>Get real-time updates on garbage quantities and optimize collection schedules.</p>
            </div>
            <div className="col-md-4 mb-4">
              <i className="bi bi-recycle fs-1 text-warning"></i>
              <h4 className="mt-3">Promote Sustainability</h4>
              <p>Encourage waste segregation and recycling for a greener environment.</p>
            </div>
          </div>
        </section>
        <hr className="featurette-divider" />

        <div className="row featurette">
          <section className="container my-5">
            <h2 className="text-center mb-4">What People Are Saying</h2>
            <div className="row">
              <div className="col-md-6 mb-4">
                <div className="card">
                  <div className="card-body">
                    <blockquote className="blockquote mb-0">
                      <p>
                        &quot;Garbage Guru has revolutionized waste management in our city. The real-time
                        tracking feature is a game-changer!&quot;
                      </p>
                      <footer className="blockquote-footer">Jane Doe, City Manager</footer>
                    </blockquote>
                  </div>
                </div>
              </div>
              <div className="col-md-6 mb-4">
                <div className="card">
                  <div className="card-body">
                    <blockquote className="blockquote mb-0">
                      <p>
                        &quot;Our neighborhoods are cleaner than ever! Garbage Guru makes waste collection
                        so much easier.&quot;
                      </p>
                      <footer className="blockquote-footer">John Smith, Resident</footer>
                    </blockquote>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>


      </div>
    </>
  )
}
