import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { enrollInEvent, getAllEvents } from "../api-request/event-request";
import { flattenObject } from "../utils/utils";
import { getAddressCategoryStatusList } from "../api-request/user-request";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2";

export default function EventPage() {
  useEffect(() => {
    document.getElementById("container").scrollTo(0, 0);
  }, []);
  const { register, handleSubmit, reset } = useForm();
  const [events, setEvents] = useState([]);
  const [areas, setAreas] = useState([]);
  const navigate = useNavigate();

  const user = useSelector((state) => state.user.userInfo);

  const [filteredEvents, setFilteredEvents] = useState([]);

  const fetchEvents = async () => {
    try {
      const response1 = await getAddressCategoryStatusList();
      console.log(response1);
      
      if (response1.status) {
        const basicData = response1.data;
        console.log(basicData);

        setAreas(basicData.address);
      }
      const response2 = await getAllEvents();
      console.log(response2);

      if (response2.status) {
        const mockEvents = response2.data.map((data) => flattenObject(data));
        console.log(mockEvents);

        setEvents(mockEvents);
        setFilteredEvents(mockEvents);
      } else {
        Swal.fire("Error", `Network Error <br/>${response1.message}`, "error");
      }
    } catch (error) {
      console.log(error);
      Swal.fire("Error", `Network Error <br/>${error}`, "error");

    }
  };

  useEffect(() => {
    fetchEvents();
  }, []);

  const onSearch = (data) => {
    const filtered = events.filter((event) => {
      return (
        (!data.name ||
          event.eventName.toLowerCase().includes(data.name.toLowerCase())) &&
        (!data.date || event.date === data.date) &&
        (!data.area ||
          event["area.areaName"]
            .toLowerCase()
            .includes(data.area.toLowerCase()))
      );
    });
    setFilteredEvents(filtered);
  };

  const clearFilters = () => {
    reset();
    setFilteredEvents(events);
  };

  const participateInEvent = async (eventId, eventName) => {
    if (!user?.firstName) {
      Swal.fire(
        "Error",
        "You Not login please Login Or Register!",
        "error"
      ).then(async () => {
        navigate("/login");
        console.log(user);
        return;
      });
    }
    if (!user.volunteer) {
      Swal.fire(
        "Error",
        "You Not register as Volunteer! <br/> For Participate in Event Register For Volunteer",
        "error"
      );
      return;
    }
    console.log(eventId);
    // return;
    const response = await enrollInEvent(
      user?.volunteerId,
      parseInt(eventId, 10)
    );
    console.log(response);
    if (response.status) {
      Swal.fire(
        "Success",
        `User Participate In ${eventName} Event successfully!`,
        "success"
      );
    } else {
      Swal.fire(
        "Error",
        `User registered failed! <br/>${response.message}`,
        "error"
      );
    }
    fetchEvents();
  };

  return (
    <div className="container mt-4">
      <h2 className="text-center mb-4">Events </h2>

      {/* Search Form */}
      <form onSubmit={handleSubmit(onSearch)} className="mb-4">
        <div className="row g-3">
          <div className="col-md-6">
            <label htmlFor=" " className="form-label">
              Event Name
            </label>
            <input
              type="text"
              className="form-control"
              placeholder="Enter Event Name"
              {...register("name")}
            />
          </div>

          <div className="col-md-6">
            <label htmlFor="area" className="form-label">
              Area
            </label>
            <select id="area" className="form-control" {...register("area")}>
              <option value="">Select Area</option>
              {areas.map((area) => (
                <option key={area.areaId} value={area.areaName}>
                  {area.areaName}
                </option>
              ))}
            </select>
          </div>
        </div>
        <div className="mt-3 text-center">
          <button type="submit" className="btn btn-primary me-2">
            Search
          </button>
          <button
            type="button"
            className="btn btn-secondary"
            onClick={clearFilters}
          >
            Clear
          </button>
        </div>
      </form>

      {/* Events List */}
      <div className="row justify-content-center">
        {filteredEvents.length > 0 ? (
          filteredEvents.map((event) => (
            <div
              className="col-md-4 mb-4 d-flex align-items-stretch "
              key={event.eventId}
            >
              <div className="card shadow-sm">
                <div className="card-body d-flex flex-column ">
                  <h5 className="card-title fs-2 text-center pb-2">
                    {event.eventName}
                  </h5>
                  <p className="card-text">
                    <strong>Area:</strong> {event["area.areaName"]} <br />
                    <strong>Date:</strong> {event.eventDate}
                    <br />
                    <strong>Remaining Seats:</strong>{" "}
                    <span className="badge bg-success">
                      {event["remainingParticipants"]}{" "}
                    </span>
                  </p>
                  <p className="card-text ">{event.description}</p>
                </div>

                <button
                  className="btn btn-success  m-2"
                  onClick={() =>
                    participateInEvent(event.eventId, event.eventName)
                  }
                >
                  <i className="bi bi-person-plus-fill"></i> Participate
                </button>
              </div>
            </div>
          ))
        ) : (
          <p className="text-center">
            No events found. Please refine your search.
          </p>
        )}
      </div>
    </div>
  );
}
