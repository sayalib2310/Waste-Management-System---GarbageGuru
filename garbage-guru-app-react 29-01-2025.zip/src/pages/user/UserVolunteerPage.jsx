import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { getEventsByVolunteerId, removeEnrollInEvent } from "../../api-request/event-request";
import { Button } from "react-bootstrap";
import Swal from "sweetalert2";

export default function UserVolunteerPage() {
  const user = useSelector((state) => state.user.userInfo);
  const [events, setEvents] = useState([]);
  useEffect(() => {
    fetchData();
  }, []);

  async function fetchData() {
    const eventData = (await getEventsByVolunteerId(user?.volunteerId)).data;
    setEvents(eventData);
    console.log("eventData", eventData);
  }

  async function handleRetrieveParticipation(eventId) {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes,",
      cancelButtonText: "No, cancel!",
    }).then(async (result) => {
      if (result.isConfirmed) {
        const response = await removeEnrollInEvent(user?.volunteerId, eventId);

        if (response.status) {
          Swal.fire("Deleted!", "User Event Participation has been deleted.", "success");
          fetchData();
        } else {
          Swal.fire("Error", "Failed to delete Participation", "error");
        }
      }
    });
  }
  return (
    <div className="mt-4">
      <h3>User Event Participation</h3>
      {events.length > 0 ? (
        <table className="table table-info table-hover table_custom mt-4">
          <thead className="table-dark">
            <tr>
              <th>Event ID</th>
              <th>Event Name</th>
              <th>Description</th>
              <th>Event Date</th>
              <th>Location</th>
              <th>Max Participants</th>
              <th>Remaining Participants</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {events.map((event, index) => (
              <tr key={event.eventId}>
                <td>{index + 1}</td>
                <td>{event.eventName}</td>
                <td>{event.description}</td>
                <td>{new Date(event.eventDate).toDateString()}</td>
                <td>{event.area.areaName}</td>
                <td>{event.maxParticipants}</td>
                <td>{event.remainingParticipants}</td>
                <td>
                  <Button variant="danger" onClick={() => handleRetrieveParticipation(event.eventId)}>
                    Retrieve Participation
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>Not Event Participation Found</p>
      )}
    </div>
  );
}
