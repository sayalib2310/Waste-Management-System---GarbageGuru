import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import { logout } from "../../redux/store";

export default function UserLayout() {
  const user = useSelector((state) => state.user.userInfo);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [isLoading,setIsLoading] = useState(true);
  useEffect(() => {
    if (user?.role.roleId !== 1) {
      Swal.fire("Error","Unauthorize Access!","error").then(async () => {
        navigate("/login");
        dispatch(logout());
      });
      return;
    }
    setIsLoading(false);
  }, []);
  return (
    isLoading?<> Loading...</>:
    <div className="container-fluid d-flex flex-column m-0">
      <div>
        <ul className="nav nav-pills nav-fill w-100 p-3">
          <li className="nav-item mx-3">
            <NavLink
              to="profile"
              aria-current="page"
              className={({ isActive }) =>
                "nav-link" +
                (isActive
                  ? " active bg-secondary"
                  : " text-secondary border border-secondary rounded")
              }
            >
              Profile
            </NavLink>
          </li>
          <li className="nav-item mx-3">
            <NavLink
              to="complaints"
              aria-current="page"
              className={({ isActive }) =>
                "nav-link " +
                (isActive
                  ? " active bg-secondary"
                  : "text-secondary border border-secondary rounded")
              }
            >
              Complaints
            </NavLink>
          </li>
          {user?.volunteer && (
            <li className="nav-item mx-3">
              <NavLink
                to="volunteers"
                aria-current="page"
                className={({ isActive }) =>
                  "nav-link " +
                  (isActive
                    ? " active bg-secondary"
                    : "text-secondary border border-secondary rounded")
                }
              >
                Events
              </NavLink>
            </li>
          )}
        </ul>
      </div>
      <main className="flex-grow-1 p-3 user-container">
        <Outlet />
      </main>
    </div>
  );
}
