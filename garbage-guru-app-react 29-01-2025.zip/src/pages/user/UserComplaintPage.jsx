import React, { useEffect, useState } from "react";
import { getComplaintsByUserId } from "../../api-request/user-request";
import { useSelector } from "react-redux";

export default function UserComplaintPage() {
  const user = useSelector((state) => state.user.userInfo);
  const [complaints, setComplaints] = useState([]);
  useEffect(() => {
    fetchData();
  }, []);

  async function fetchData() {
    const complaintData = (await getComplaintsByUserId(user?.userId)).data;
    setComplaints(complaintData);
    console.log("User Profile", complaintData);
  }

  function getStatusColor(status) {
    switch (status) {
      case "OPEN":
        return "badge bg-danger";
      case "IN_PROGRESS":
        return "badge bg-warning";
      case "RESOLVED":
        return "badge bg-success";
      default:
        return "badge bg-secondary";
    }
  }
  return (
    <div className=" mt-4">
      {complaints.length > 0 ?
      <table className="table table-info table-hover  table_custom mt-4 ">
        <thead className="table-dark">
          <tr>
            <th>Complaint ID</th>
            <th>Issue</th>
            <th>Address</th>
            <th>Area</th>
            <th>Dustbin</th>
            <th>Created At</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {complaints.map((complaint) => (
            <tr key={complaint.complaintId}>
              <td>{complaint.complaintId}</td>
              <td>{complaint.issue}</td>
              <td>{complaint.address || "Not Provided"}</td>
              <td>{complaint.area.areaName}</td>
              <td>
                {complaint.dustbin ? (
                  <>
                    <p>{`Dustbin No: ${complaint.dustbin.dustNo}`}</p>
                    <p>{`Category: ${complaint.dustbin.category.categoryName}`}</p>
                    <p>{`Status: ${complaint.dustbin.status.statusName}`}</p>
                  </>
                ) : (
                  "No Dustbin Assigned"
                )}
              </td>
              <td>{new Date(complaint.createdAt).toUTCString()}</td>
              <td>
                <span className={getStatusColor(complaint.status.trim())}>{complaint.status}</span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>:<>No Complaints Found</>}
    </div>
  );
}
