import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { getAddressCategoryStatusList, getUserById, getVolunteerByVolunteerId, updateUserById } from "../../api-request/user-request";
import { useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { Button, Modal } from "react-bootstrap";
import Swal from "sweetalert2";

export default function UserProfile() {
  const user = useSelector((state) => state.user.userInfo);
  const [profile, setProfile] = useState();
  const [volunteerProfile, setVolunteerProfile] = useState();
  const [showModal, setShowModal] = useState(false);
  const [areas, setAreas] = useState([]);
  useEffect(() => {
    fetchData();
  }, []);

  async function fetchData() {
    const userProfileData = (await getUserById(user?.userId)).data;
    const volunteerProfileData = (await getVolunteerByVolunteerId(user?.volunteerId)).data;
    console.log("User Profile", userProfileData);
    console.log("User Profile", volunteerProfileData);
    const basicData = (await getAddressCategoryStatusList()).data;
    console.log(basicData);

    setAreas(basicData.address);
    setProfile(userProfileData);
    setVolunteerProfile(volunteerProfileData);
  }

  const handleUpdate = async (data) => {
    const updateData = { ...profile, ...data };
    console.log("Updated Data:", updateData);

    const response = await updateUserById(profile?.userId, { ...updateData });
    if (response.status) {
      Swal.fire("Success", "User updated successfully", "success");

      reset();
      setShowModal(false);
      await fetchData();
    } else {
      Swal.fire("Error", "Failed to update user", "error");
    }
  };

  const {
    register,
    handleSubmit,
    watch,
    reset,
    formState: { errors },
  } = useForm();

  if (!profile) return <div>Loading...</div>;

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between align-items-center">
        <h2>User Profile</h2>
        <Button onClick={() => setShowModal(true)}>Update</Button>
      </div>
      <div className="row mt-3">
        <h4>Basic Information</h4>

        <div className=" col-md-6 mb-3">
          <label className="form-label">
            <strong>First Name:</strong>
          </label>
          <input type="text" className="form-control" value={profile.firstName} readOnly />
        </div>
        <div className="col-md-6 mb-3">
          <label className="form-label">
            <strong>Last Name:</strong>
          </label>
          <input type="text" className="form-control" value={profile.lastName} readOnly />
        </div>
        <div className="col-md-6 mb-3">
          <label className="form-label">
            <strong>Username:</strong>
          </label>
          <input type="text" className="form-control" value={profile.userName} readOnly />
        </div>
        <div className="col-md-6 mb-3">
          <label className="form-label">
            <strong>Email:</strong>
          </label>
          <input type="email" className="form-control" value={profile.emailId} readOnly />
        </div>
        <div className="col-md-6 mb-3">
          <label className="form-label">
            <strong>Contact No:</strong>
          </label>
          <input type="text" className="form-control" value={profile.contactNo} readOnly />
        </div>
      </div>
      <div className="row mt-3">
        <h4>Additional Details</h4>
        <div className="col-md-6 mb-3">
          <label className="form-label">
            <strong>Aadhar No:</strong>
          </label>
          <input type="text" className="form-control" value={profile.aadharNo} readOnly />
        </div>
        <div className="col-md-6 mb-3">
          <label className="form-label">
            <strong>Address:</strong>
          </label>
          <input type="text" className="form-control" value={profile.address} readOnly />
        </div>
        <div className="col-md-6 mb-3">
          <label className="form-label">
            <strong>Area:</strong>
          </label>
          <input type="text" className="form-control" value={profile.area.areaName} readOnly />
        </div>
        <div className="col-md-6 mb-3">
          <label className="form-label">
            <strong>Role:</strong>
          </label>
          <input type="text" className="form-control" value={profile.role.roleName} readOnly />
        </div>
        <div className="col-md-6 mb-3">
          <label className="form-label">
            <strong>Volunteer:</strong>
          </label>
          <input type="text" className="form-control" value={profile.volunteer ? "Yes" : "No"} readOnly />
        </div>
      </div>

      {profile.volunteer && <div className="row mt-3">
        <h4>Volunteer Details</h4>
        <div className="col-md-6 mb-3">
          <label className="form-label">
            <strong>Department:</strong>
          </label>
          <input type="text" className="form-control" value={volunteerProfile.department} readOnly />
        </div>
        <div className="col-md-6 mb-3">
          <label className="form-label">
            <strong>Purpose:</strong>
          </label>
          <input type="text" className="form-control" value={volunteerProfile.purpose} readOnly />
        </div>
        <div className="col-md-6 mb-3">
          <label className="form-label">
            <strong>Experience:</strong>
          </label>
          <input type="text" className="form-control" value={volunteerProfile.experience} readOnly />
        </div>
      </div>}
      

      <Modal
        size="lg"
        scrollable
        show={showModal}
        onHide={() => {
          reset();
          setShowModal(false);
        }}
      >
        <Modal.Header closeButton>
          <Modal.Title>Update Profile</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form onSubmit={handleSubmit(handleUpdate)}>
            <div className="row w-100 g-3 mb-5 m-1">
              <div className="col-6">
                <label htmlFor="firstName" className="form-label">
                  First Name
                </label>
                <input
                  type="text"
                  id="firstName"
                  className="form-control"
                  defaultValue={profile.firstName}
                  {...register("firstName", { required: "First name is required" })}
                />
                {errors.firstName && <small className="text-danger">{errors.firstName.message}</small>}
              </div>
              <div className="col-6">
                <label htmlFor="lastName" className="form-label">
                  Last Name
                </label>
                <input
                  type="text"
                  id="lastName"
                  className="form-control"
                  defaultValue={profile.lastName}
                  {...register("lastName", { required: "Last name is required" })}
                />
                {errors.lastName && <small className="text-danger">{errors.lastName.message}</small>}
              </div>
              <div className="col-12">
                <label htmlFor="emailId" className="form-label">
                  Email
                </label>
                <input
                  type="email"
                  id="emailId"
                  className="form-control"
                  defaultValue={profile.emailId}
                  {...register("emailId", {
                    required: "Email is required",
                    pattern: {
                      value: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/,
                      message: "Invalid email address",
                    },
                  })}
                />
                {errors.emailId && <small className="text-danger">{errors.emailId.message}</small>}
              </div>
              <div className="col-12">
                <label htmlFor="contactNo" className="form-label">
                  Contact Number
                </label>
                <input
                  type="text"
                  id="contactNo"
                  className="form-control"
                  defaultValue={profile.contactNo}
                  {...register("contactNo", {
                    required: "Contact number is required",
                    pattern: {
                      value: /^[0-9]{10}$/,
                      message: "Invalid contact number",
                    },
                  })}
                />
                {errors.contactNo && <small className="text-danger">{errors.contactNo.message}</small>}
              </div>
              <div className="col-12">
                <label htmlFor="userName" className="form-label">
                  Username
                </label>
                <input
                  type="text"
                  id="userName"
                  className="form-control"
                  disabled
                  defaultValue={profile.userName}
                  {...register("userName", { required: "Username is required" })}
                />
                {errors.userName && <small className="text-danger">{errors.userName.message}</small>}
              </div>

              <div className="col-12">
                <label htmlFor="aadharNo" className="form-label">
                  Aadhar Number
                </label>
                <input
                  type="text"
                  id="aadharNo"
                  className="form-control"
                  defaultValue={profile.aadharNo}
                  {...register("aadharNo", {
                    required: "Aadhar number is required",
                    pattern: {
                      value: /^[0-9]{12}$/,
                      message: "Invalid Aadhar number",
                    },
                  })}
                />
                {errors.aadharNo && <small className="text-danger">{errors.aadharNo.message}</small>}
              </div>
              <div className="col-12">
                <label htmlFor="address" className="form-label">
                  Address
                </label>
                <textarea
                  id="address"
                  className="form-control"
                  rows="2"
                  defaultValue={profile.address}
                  {...register("address", { required: "Address is required" })}
                ></textarea>
                {errors.address && <small className="text-danger">{errors.address.message}</small>}
              </div>
              <div className="col-12">
                <label htmlFor="area" className="form-label">
                  Area
                </label>
                <select
                  id="areaId"
                  className="form-select"
                  defaultValue={profile.area.areaId}
                  {...register("areaId", { required: "Please select an area" })}
                >
                  <option value="">Select Area</option>
                  {/* Populate with areas from API */}
                  {areas.map((area) => (
                    <option key={area.areaId} value={area.areaId}>
                      {area.areaName}
                    </option>
                  ))}
                </select>
                {errors.area && <small className="text-danger">{errors.area.message}</small>}
              </div>
              <div className="d-grid">
                <Button type="submit" className="btn btn-primary">
                  Save Changes
                </Button>
              </div>
            </div>
          </form>
        </Modal.Body>
      </Modal>
    </div>
  );
}
