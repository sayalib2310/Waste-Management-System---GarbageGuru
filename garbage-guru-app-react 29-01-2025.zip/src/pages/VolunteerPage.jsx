import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom';

import volunteerImage from "../assets/international-volunteer-day-with-volunteers-cleaning-park_861346-59379.jpg";
import image1 from "../assets/image_1.jpg";
import image2 from "../assets/image_2.jpg";
import image3 from "../assets/image_3.jpg";
import image6 from "../assets/image_6.jpg";

export default function VolunteerPage() {
  const navigate = useNavigate();

  const handleRegister = () => {
    navigate("/volunteer-registration");
  };
  useEffect(() => {
    document.getElementById("container").scrollTo(0, 0);

  }, []);


  return (
    <div className="container mt-5">
      <h1 className="text-center mb-4">Become a Volunteer</h1>
      <div className="row flex justify-content-between align-items-center">
        <div className="col-md-6 ">
          <h2>Why Volunteers Matter</h2>
          <p>
            Volunteers are the backbone of our community projects. Their dedication and selflessness
            drive change and make our initiatives successful. By giving your time and effort, you
            can create a cleaner, greener, and better city.
          </p>
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur, similique? Blanditiis illo quae repudiandae nesciunt officia vel similique quisquam facere sunt delectus vero accusantium, cumque corrupti laborum repellat, error eum.
          </p>
        </div>
        <div className="col-md-5">
          <img
            src={volunteerImage}
            alt="Volunteers"
            style={{ width: "100%", height: "20rem" }}
            className="img-fluid rounded"
          />
        </div>
      </div>

      <hr className="featurette-divider" />


      <div className="mb-5">
        <h2 className="text-center mb-4">How Volunteers Help Us</h2>
        <div className="row g-5  align-items-center justify-content-center">
          <div className="col-10">
            <div className="card shadow-sm">
              <div className="row g-0">
                <div className="col-md-5">
                  <img
                    src={image1}

                    alt="Clean City Drives"
                    className="img-fluid rounded-start"
                  />
                </div>
                <div className="col-md-7">
                  <div className="card-body">
                    <h5 className="card-title">Clean City Drives</h5>
                    <p className="card-text">
                      Helping clean streets, parks, and neighborhoods to make our city a better place to
                      live.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="col-10">
            <div className="card shadow-sm">
              <div className="row g-0">

                <div className="col-md-7">
                  <div className="card-body">
                    <h5 className="card-title">Recycling Campaigns</h5>
                    <p className="card-text">
                      Raising awareness about proper waste management and recycling to promote a
                      sustainable future.
                    </p>
                  </div>
                </div>
                <div className="col-md-5">
                  <img
                    src={image2}
                    alt="Recycling Campaigns"
                    className="img-fluid rounded-start"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="col-10">
            <div className="card shadow-sm">
              <div className="row g-0">
                <div className="col-md-5">
                  <img
                    src={image6}
                    alt="Community Events"
                    className="img-fluid rounded-start"
                  />
                </div>
                <div className="col-md-7">
                  <div className="card-body">
                    <h5 className="card-title">Community Events</h5>
                    <p className="card-text">
                      Organizing and managing city-wide environmental activities to bring the community
                      together for a common cause.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="col-10">
            <div className="card shadow-sm">
              <div className="row g-0">

                <div className="col-md-7">
                  <div className="card-body">
                    <h5 className="card-title">Education</h5>
                    <p className="card-text">
                      Teaching others about sustainable living, waste reduction, and how to contribute to
                      a cleaner environment.
                    </p>
                  </div>
                </div>
                <div className="col-md-5">
                  <img
                    src={image3}

                    alt="Education"
                    className="img-fluid rounded-start"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <hr className="featurette-divider" />

      <div className="mb-5">
        <h2 className="text-center mb-4">Benefits of Being a Volunteer</h2>
        <div className="row g-4">
          <div className="col-md-6 col-lg-4">
            <div className="card shadow-lg border-0">
              <div className="card-body text-center">
                <div className="mb-3">
                  <i className="bi bi-emoji-smile fs-1 text-primary"></i>
                </div>
                <h5 className="card-title">Make a Difference</h5>
                <p className="card-text">
                  Play a crucial role in building a sustainable environment by actively participating in
                  cleanups, awareness drives, and campaigns.
                </p>
              </div>
            </div>
          </div>

          <div className="col-md-6 col-lg-4">
            <div className="card shadow-lg border-0">
              <div className="card-body text-center">
                <div className="mb-3">
                  <i className="bi bi-tools fs-1 text-success"></i>
                </div>
                <h5 className="card-title">Build Skills</h5>
                <p className="card-text">
                  Enhance your leadership, communication, and teamwork skills while gaining experience in
                  environmental management.
                </p>
              </div>
            </div>
          </div>

          <div className="col-md-6 col-lg-4">
            <div className="card shadow-lg border-0">
              <div className="card-body text-center">
                <div className="mb-3">
                  <i className="bi bi-people fs-1 text-info"></i>
                </div>
                <h5 className="card-title">Meet Like-Minded People</h5>
                <p className="card-text">
                  Connect with a network of passionate individuals who share your love for the
                  environment, fostering friendships and collaborations.
                </p>
              </div>
            </div>
          </div>

          <div className="col-md-6 col-lg-4">
            <div className="card shadow-lg border-0">
              <div className="card-body text-center">
                <div className="mb-3">
                  <i className="bi bi-lightbulb fs-1 text-warning"></i>
                </div>
                <h5 className="card-title">Gain Knowledge</h5>
                <p className="card-text">
                  Learn about waste management practices, recycling techniques, and sustainable living
                  strategies to apply in your daily life.
                </p>
              </div>
            </div>
          </div>

          <div className="col-md-6 col-lg-4 ">
            <div className="card shadow-lg border-0">
              <div className="card-body text-center">
                <div className="mb-3">
                  <i className="bi bi-award fs-1 text-danger"></i>
                </div>
                <h5 className="card-title">Earn Recognition</h5>
                <p className="card-text">
                  Receive certificates, awards, and community acknowledgment for your contributions to
                  the cause. Lorem ipsum dolor sit amet consectetur
                </p>
              </div>
            </div>
          </div>

          <div className="col-md-6 col-lg-4">
            <div className="card shadow-lg border-0">
              <div className="card-body text-center">
                <div className="mb-3">
                  <i className="bi bi-heart fs-1 text-pink"></i>
                </div>
                <h5 className="card-title">Personal Fulfillment</h5>
                <p className="card-text">
                  Experience the joy of giving back to your community and making a lasting positive
                  impact on the environment.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <hr className="featurette-divider" />



      <div className="text-center">
        <h3>Join Us Today!</h3>
        <p className="mb-4">
          Be a part of our mission to create a cleaner and greener future. Together, we can make a
          difference.
        </p>
        <button className="btn btn-primary btn-lg" onClick={handleRegister}>
          Register as Volunteer
        </button>
      </div>
    </div>
  );
}
