import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { getDustbins } from "../api-request/dustbin-request";
import { flattenObject } from "../utils/utils";
import { getAddressCategoryStatusList } from "../api-request/user-request";

export default function DustbinPage() {
  const { register, handleSubmit, reset } = useForm();
  const [dustbins, setDustbins] = useState([]);
  const [areas, setAreas] = useState([]);
  const [categories, setCategories] = useState([]);

  // Scroll to top when component loads
  useEffect(() => {
    document.getElementById("container").scrollTo(0, 0);
  }, []);

  // Fetch dustbins (mock data fetching, replace with actual API call)
  const fetchDustbins = async (filters = null) => {
    try {
      const mockData = (await getDustbins())?.data.map((data) =>
        flattenObject(data)
      );

      const basicData = (await getAddressCategoryStatusList()).data;
      console.log(basicData);

      setAreas(basicData.address);
      setCategories(basicData.category);

      console.log(mockData);

      if (filters) {
        console.log(filters);

        const filtered = mockData.filter((dustbin) => {
          return (
            (!filters.dustbinNo ||
              dustbin.dustNo.toString().includes(filters.dustbinNo)) &&
            (!filters.area ||
              dustbin["area.areaName"]
                .toLowerCase()
                .includes(filters.area.toLowerCase())) &&
            (!filters.category ||
              dustbin["category.categoryName"]
                .toLowerCase()
                .includes(filters.category.toLowerCase()))
          );
        });
        setDustbins(filtered);
      } else {
        setDustbins(mockData); // Show all dustbins by default
      }
    } catch (error) {
      
    }
  };

  // Initial data load
  useEffect(() => {
    fetchDustbins(); // Load all dustbins on page load
  }, []);

  // Filter submission handler
  const onSubmit = (data) => {
    fetchDustbins(data);
  };

  // Clear filters and reset form
  const clearFilters = () => {
    reset();
    fetchDustbins();
  };

  return (
    <div className="container mt-4">
      <h2 className="text-center mb-4">Find Your Near Dustbin</h2>

      {/* Search Form */}
      <form onSubmit={handleSubmit(onSubmit)} className="mb-4">
        <div className="row g-3">
          <div className="col-md-4">
            <label htmlFor="dustbinNo" className="form-label">
              Dustbin No
            </label>
            <input
              type="text"
              id="dustbinNo"
              className="form-control"
              placeholder="Enter Dustbin No"
              {...register("dustbinNo")}
            />
          </div>
          <div className="col-md-4">
            <label htmlFor="area" className="form-label">
              Area
            </label>
            <select id="area" className="form-control" {...register("area")}>
              <option value="">Select Area</option>
              {areas.map((area) => (
                <option key={area.areaId} value={area.areaName}>
                  {area.areaName}
                </option>
              ))}
            </select>
          </div>
          <div className="col-md-4">
            <label htmlFor="category" className="form-label">
              Category
            </label>
            <select
              id="category"
              className="form-control"
              {...register("category")}
            >
              <option value="">Select Category</option>
              {categories.map((category) => (
                <option key={category.categoryId} value={category.categoryName}>
                  {category.categoryName}
                </option>
              ))}
            </select>
          </div>
        </div>
        <div className="mt-3 text-center">
          <button type="submit" className="btn btn-primary me-2">
            Search
          </button>
          <button
            type="button"
            className="btn btn-secondary"
            onClick={clearFilters}
          >
            Clear
          </button>
        </div>
      </form>

      {/* Dustbin Cards */}
      <div className="row">
        {dustbins.length > 0 ? (
          dustbins.map((dustbin, index) => (
            <div className="col-md-4 mb-4" key={dustbin.dustbinId}>
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">Dustbin No: {dustbin.dustNo}</h5>
                  <h6 className="card-subtitle mb-2 text-muted">
                    Area: {dustbin["area.areaName"]}
                  </h6>
                  <p className="card-text">
                    <strong>Category:</strong>{" "}
                    {dustbin["category.categoryName"]} <br />
                    <strong>Allocated Date:</strong> {dustbin.allocatedDate}{" "}
                    <br />
                    <strong>Last Cleaned:</strong> {dustbin.lastCleanDate}{" "}
                    <br />
                    <strong>Garbage Quantity:</strong> {dustbin.garbageQtyInKg}{" "}
                    Kg
                    <br />
                    <strong>Status:</strong>
                    {"   "}
                    <span className={`badge bg-success`}>
                      {dustbin["status.statusName"]}
                    </span>
                  </p>
                </div>
              </div>
            </div>
          ))
        ) : (
          <p className="text-center">
            No dustbins found. Please refine your search.
          </p>
        )}
      </div>
    </div>
  );
}
