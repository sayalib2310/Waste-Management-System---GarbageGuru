import React, { useEffect, useState } from "react";
import { deleteComplaint, getComplaints, updateComplaintStatus } from "../../api-request/admin-request";
import { flattenObject } from "../../utils/utils";
import Swal from "sweetalert2";
import { Button, Form, Modal } from "react-bootstrap";
import { useForm } from "react-hook-form";

export default function ComplaintsManage() {
  const { register, handleSubmit, reset, setValue } = useForm();
  const [complaints, setComplaints] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [currentComplaint, setCurrentComplaint] = useState(null);
  const [showViewModal, setShowViewModal] = useState(false);
  const [showStatusModal, setShowStatusModal] = useState(false);

  // Fetch complaints from API
  const fetchComplaints = async () => {
    try {
      const response = (await getComplaints()).data.map((data) => flattenObject(data));
      setComplaints(response);
      setFiltered(response);
    } catch (error) {
      Swal.fire("Error", "Failed to fetch complaints", "error");
    }
  };

  useEffect(() => {
    fetchComplaints(); // Load complaints on page load
  }, []);

  // Update complaint status
  const handleUpdateStatus = async (data) => {
    try {
      const response = await updateComplaintStatus(currentComplaint.complaintId, data.status);
      if (response.status) {
        Swal.fire("Success", "Status updated successfully", "success");
        fetchComplaints();
        reset();
        setShowStatusModal(false);
      } else {
        Swal.fire("Error", response.message, "error");
      }
    } catch (error) {
      Swal.fire("Error", "Failed to update status", "error");
    }
  };

  // Delete a complaint
  const handleDeleteComplaint = (complaintId) => {
    Swal.fire({
      title: "Are you sure?",
      text: "This action cannot be undone.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "No, cancel!",
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          await deleteComplaint(complaintId);
          Swal.fire("Deleted!", "Complaint has been deleted.", "success");
          fetchComplaints();
        } catch (error) {
          Swal.fire("Error", "Failed to delete complaint", "error");
        }
      }
    });
  };

  // View complaint details
  const handleViewComplaint = (complaint) => {
    setCurrentComplaint(complaint);
    setShowViewModal(true);
  };

  // Open status update modal
  const handleStatusModal = (complaint) => {
    setCurrentComplaint(complaint);
    setShowStatusModal(true);
  };

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between mb-3">
        <input
          type="text"
          className="form-control w-25"
          placeholder="Search by Issue, User, Area"
          onChange={(event) => {
            const query = event.target.value.toLowerCase();
            const filteredComplaints = complaints.filter(
              (complaint) =>
                complaint.issue.toLowerCase().includes(query) ||
                complaint["user.firstName"].toLowerCase().includes(query) ||
                complaint["area.areaName"].toLowerCase().includes(query) ||
                !query
            );
            setFiltered(filteredComplaints);
          }}
        />
      </div>

      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Complaint ID</th>
            <th>Issue</th>
            <th>User</th>
            <th>Area</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map((complaint) => (
            <tr key={complaint.complaintId}>
              <td>{complaint.complaintId}</td>
              <td>{complaint.issue}</td>
              <td>{`${complaint["user.firstName"]} ${complaint["user.lastName"]}`}</td>
              <td>{complaint["area.areaName"]}</td>
              <td>{complaint.status}</td>
              <td>
                <button className="btn btn-sm btn-info" onClick={() => handleViewComplaint(complaint)}>
                  View
                </button>
                <button className="btn btn-sm btn-warning mx-2" onClick={() => handleStatusModal(complaint)}>
                  Update Status
                </button>
                <button className="btn btn-sm btn-danger" onClick={() => handleDeleteComplaint(complaint.complaintId)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* View Complaint Modal */}
      <Modal show={showViewModal} onHide={() => setShowViewModal(false)} size="lg" scrollable={true}>
        <Modal.Header closeButton>
          <Modal.Title>Complaint Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {currentComplaint && (
            <>
              {/* Issue Section */}
              <div className="mb-3">
                <h5>Details</h5>
                <div className="row">
                  <div className="col-md-12">
                    <Form.Group>
                      <Form.Label>Issue</Form.Label>
                      <Form.Control type="text" value={currentComplaint.issue} readOnly />
                    </Form.Group>
                  </div>
                  <div className="col-md-6">
                    <Form.Group>
                      <Form.Label>Complaint Address</Form.Label>
                      <Form.Control type="text" value={currentComplaint["address"]} readOnly />
                    </Form.Group>
                  </div>
                  <div className="col-md-6">
                    <Form.Group>
                      <Form.Label>Complaint Area</Form.Label>
                      <Form.Control type="text" value={currentComplaint["area.areaName"]} readOnly />
                    </Form.Group>
                  </div>
                </div>
              </div>

              {/* User Information Section */}
              <div className="mb-3">
                <h5>User Information</h5>
                <div className="row">
                  <div className="col-md-6">
                    <Form.Group>
                      <Form.Label>Name</Form.Label>
                      <Form.Control type="text" value={`${currentComplaint["user.firstName"]} ${currentComplaint["user.lastName"]}`} readOnly />
                    </Form.Group>
                  </div>
                  <div className="col-md-6">
                    <Form.Group>
                      <Form.Label>Email</Form.Label>
                      <Form.Control type="text" value={currentComplaint["user.emailId"]} readOnly />
                    </Form.Group>
                  </div>
                  <div className="col-md-6">
                    <Form.Group>
                      <Form.Label>Contact No</Form.Label>
                      <Form.Control type="text" value={currentComplaint["user.contactNo"]} readOnly />
                    </Form.Group>
                  </div>
                  <div className="col-md-6">
                    <Form.Group>
                      <Form.Label>Address</Form.Label>
                      <Form.Control type="text" value={currentComplaint["user.address"] || "N/A"} readOnly />
                    </Form.Group>
                  </div>
                  <div className="col-md-6">
                    <Form.Group>
                      <Form.Label>Area</Form.Label>
                      <Form.Control type="text" value={currentComplaint["user.area.areaName"]} readOnly />
                    </Form.Group>
                  </div>
                </div>
              </div>

             

              {/* Dustbin Details Section */}
              <div className="mb-3">
                <h5>Dustbin Details</h5>
                <div className="row">
                  <div className="col-md-6">
                    <Form.Group>
                      <Form.Label>Dustbin No</Form.Label>
                      <Form.Control type="text" value={currentComplaint["dustbin.dustNo"]} readOnly />
                    </Form.Group>
                  </div>
                  <div className="col-md-6">
                    <Form.Group>
                      <Form.Label>Category</Form.Label>
                      <Form.Control type="text" value={currentComplaint["dustbin.category.categoryName"]} readOnly />
                    </Form.Group>
                  </div>
                  <div className="col-md-6">
                    <Form.Group>
                      <Form.Label>Area</Form.Label>
                      <Form.Control type="text" value={currentComplaint["dustbin.area.areaName"]} readOnly />
                    </Form.Group>
                  </div>
                  <div className="col-md-6">
                    <Form.Group>
                      <Form.Label>Last Cleaned Date</Form.Label>
                      <Form.Control type="text" value={currentComplaint["dustbin.lastCleanDate"]} readOnly />
                    </Form.Group>
                  </div>
                  <div className="col-md-6">
                    <Form.Group>
                      <Form.Label>Garbage Quantity (kg)</Form.Label>
                      <Form.Control type="text" value={currentComplaint["dustbin.garbageQtyInKg"]} readOnly />
                    </Form.Group>
                  </div>
                </div>
              </div>

              {/* Complaint Metadata Section */}
              <div className="mb-3">
                <h5>Complaint Metadata</h5>
                <div className="row">
                  <div className="col-md-6">
                    <Form.Group>
                      <Form.Label>Created At</Form.Label>
                      <Form.Control type="text" value={new Date(currentComplaint.createdAt).toUTCString()} readOnly />
                    </Form.Group>
                  </div>
                  <div className="col-md-6">
                    <Form.Group>
                      <Form.Label>Status</Form.Label>
                      <Form.Control type="text" value={currentComplaint.status} readOnly />
                    </Form.Group>
                  </div>
                </div>
              </div>
            </>
          )}
        </Modal.Body>
      </Modal>

      {/* Update Status Modal */}
      <Modal show={showStatusModal} onHide={() => setShowStatusModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Update Complaint Status</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleSubmit(handleUpdateStatus)}>
            <Form.Group className="mb-2">
              <Form.Label>Status</Form.Label>
              <Form.Select {...register("status", { required: true })}>
                <option value="OPEN">OPEN</option>
                <option value="IN_PROGRESS">IN_PROGRESS</option>
                <option value="RESOLVED">RESOLVED</option>
              </Form.Select>
            </Form.Group>
            <Button type="submit" variant="primary">
              Update
            </Button>
          </Form>
        </Modal.Body>
      </Modal>
    </div>
  );
}
