import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { createDustbin, deleteDustbinById, getDustbins, updateDustbinById } from "../../api-request/dustbin-request";
import { flattenObject } from "../../utils/utils";
import Swal from "sweetalert2";
import { getAddressCategoryStatusList } from "../../api-request/user-request";
import { Button, Form, Modal } from "react-bootstrap";

export default function DustbinManage() {
  const { register, handleSubmit, reset, setValue } = useForm();
  const [dustbins, setDustbins] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [currentDustbin, setCurrentDustbin] = useState(null);
  const [areas, setAreas] = useState([]);
  const [categories, setCategories] = useState([]);
  const [status, setStatus] = useState([]);
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  // Fetch dustbins from API
  const fetchDustbins = async () => {
    try {
      const response = (await getDustbins()).data.map((data) => flattenObject(data));
      const basicData = (await getAddressCategoryStatusList()).data;
      console.log(basicData);

      setAreas(basicData.address);
      setCategories(basicData.category);
      setStatus(basicData.status);
      setDustbins(response);
      setFiltered(response);
    } catch (error) {
      Swal.fire("Error", "Failed to fetch dustbins", "error");
    }
  };

  useEffect(() => {
    fetchDustbins(); // Load dustbins on page load
  }, []);

  // Add a new dustbin
  const handleAddDustbin = async (data) => {
    console.log(data);
    const requestBody = transformDustbinObject(data);
    const response = await createDustbin(requestBody);
    console.log(response);

    if (response.status) {
      Swal.fire("Success", "Dustbin added successfully", "success");
      fetchDustbins(); // Refresh list
      reset();
    } else {
      Swal.fire("Error", "Failed to add dustbin " + response.message, "error");
    }

    handleClose();
  };

  function transformDustbinObject(input) {
    // Map the input object to the desired output format
    return {
      allocatedDate: input.allocatedDate,
      lastCleanDate: input.allocatedDate, // Assuming lastCleanDate is the same as allocatedDate
      garbageQtyInKg: parseInt(input.garbageQtyInKg, 10), // Convert garbageQtyInKg to a number
      statusId: parseInt(input.statusId, 10), // Convert statusId to a number
      areaId: parseInt(input.areaId, 10), // Convert areaId to a number
      categoryId: parseInt(input.categoryId, 10), // Convert categoryId to a number
      dustNo: parseInt(input.dustNo, 10), // Convert dustNo to a number
    };
  }
  // Update an existing dustbin
  const handleUpdateDustbin = async (data) => {
    const response = await updateDustbinById(data.dustbinId, data);
    if (response.status) {
      Swal.fire("Success", "Dustbin updated successfully", "success");
      fetchDustbins(); // Refresh list
      reset();
      handleClose();
    } else {
      Swal.fire("Error",response.message , "error");
    }
  };

  // Delete a dustbin
  const handleDeleteDustbin = (dustbinId) => {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "No, cancel!",
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          await deleteDustbinById(dustbinId);
          Swal.fire("Deleted!", "Dustbin has been deleted.", "success");
          fetchDustbins(); // Refresh list
        } catch (error) {
          Swal.fire("Error", "Failed to delete dustbin", "error");
        }
      }
    });
  };

  // Set form values for edit
  const handleEditDustbin = (dustbin) => {
    setCurrentDustbin(dustbin);
    setValue("dustbinId", dustbin.dustbinId);
    setValue("allocatedDate", dustbin.allocatedDate);
    setValue("lastCleanDate", dustbin.lastCleanDate);
    setValue("garbageQtyInKg", dustbin.garbageQtyInKg);
    setValue("dustNo", dustbin.dustNo);
    setValue("areaId", dustbin["area.areaId"]);
    setValue("categoryId", dustbin["category.categoryId"]);
    setValue("statusId", dustbin["status.statusId"]);

    handleShow();
  };

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between mb-3">
        <button
          className="btn btn-primary"
          data-bs-toggle="modal"
          data-bs-target="#dustbinModal"
          onClick={() => {
            handleShow();
            setCurrentDustbin(null);
            reset();
          }}
        >
          Add Dustbin
        </button>
        <input
          type="text"
          className="form-control w-25"
          placeholder="Search by No, Area, Category"
          onChange={(event) => {
            const query = event.target.value.toLowerCase();
            const filteredDustbins = dustbins.filter(
              (dustbin) =>
                dustbin.dustNo.toString().includes(query) ||
                dustbin["area.areaName"].toLowerCase().includes(query) ||
                dustbin["category.categoryName"].toLowerCase().includes(query)||!query
            );
            setFiltered(filteredDustbins);
          }}
        />
      </div>

      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Dustbin No</th>
            <th>Allocate Date</th>
            <th>Last Clean Date</th>
            <th>Garbage Qty (kg)</th>
            <th>Area</th>
            <th>Category</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map((dustbin) => (
            <tr key={dustbin.dustbinId}>
              <td>{dustbin.dustNo}</td>
              <td>{dustbin.allocatedDate}</td>
              <td>{dustbin.lastCleanDate}</td>
              <td>{dustbin.garbageQtyInKg}</td>
              <td>{dustbin["area.areaName"]}</td>
              <td>{dustbin["category.categoryName"]}</td>
              <td>
                <button
                  className="btn btn-sm btn-info"
                  data-bs-toggle="modal"
                  data-bs-target="#dustbinModal"
                  onClick={() => handleEditDustbin(dustbin)}
                >
                  Edit
                </button>
                <button className="btn btn-sm btn-danger mx-2" onClick={() => handleDeleteDustbin(dustbin.dustbinId)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Modal for Add and Edit */}
      <Modal show={show} onHide={handleClose} backdrop="static" scrollable={true} keyboard={false}>
        <Modal.Header closeButton>
          <Modal.Title>{currentDustbin ? "Update Dustbin" : "Add Dustbin"}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleSubmit(currentDustbin ? handleUpdateDustbin : handleAddDustbin)}>
            <Form.Control type="hidden" {...register("dustbinId")} />

            <Form.Group className="mb-2">
              <Form.Label>Dustbin No</Form.Label>
              <Form.Control type="number" {...register("dustNo", { required: true })} />
            </Form.Group>

            <Form.Group className="mb-2">
              <Form.Label>Allocate Date</Form.Label>
              <Form.Control type="date" {...register("allocatedDate", { required: true })} />
            </Form.Group>

            {currentDustbin && (
              <Form.Group className="mb-2">
                <Form.Label>Last Clean Date</Form.Label>
                <Form.Control type="date" {...register("lastCleanDate")} />
              </Form.Group>
            )}

            <Form.Group className="mb-2">
              <Form.Label>Garbage Qty (kg)</Form.Label>
              <Form.Control type="number" {...register("garbageQtyInKg")} />
            </Form.Group>

            <Form.Group className="mb-2">
              <Form.Label>Area</Form.Label>
              <Form.Select {...register("areaId", { required: true })}>
                <option value="">Select Area</option>
                {areas.map((area) => (
                  <option key={area.areaId} value={area.areaId}>
                    {area.areaName}
                  </option>
                ))}
              </Form.Select>
            </Form.Group>

            <Form.Group className="mb-2">
              <Form.Label>Category</Form.Label>
              <Form.Select {...register("categoryId", { required: true })}>
                <option value="">Select Category</option>
                {categories.map((category) => (
                  <option key={category.categoryId} value={category.categoryId}>
                    {category.categoryName}
                  </option>
                ))}
              </Form.Select>
            </Form.Group>

            <Form.Group className="mb-2">
              <Form.Label>Status</Form.Label>
              <Form.Select {...register("statusId", { required: true })}>
                <option value="">Select Status</option>
                {status.map((data) => (
                  <option key={data.statusId} value={data.statusId}>
                    {data.statusName}
                  </option>
                ))}
              </Form.Select>
            </Form.Group>

            <Button type="submit" variant="primary">
              Save
            </Button>
          </Form>
        </Modal.Body>
      </Modal>
    </div>
  );
}
