import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link, Outlet, useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import { logout } from "../../redux/store";

export default function AdminLayout() {
  const user = useSelector((state) => state.user.userInfo);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [isLoading,setIsLoading] = useState(true);
  useEffect(() => {
    if (user?.role.roleId !== 2) {
      Swal.fire(
        "Error",
        "Unauthorize Access!",
        "error"
      ).then(async () => {
        navigate("/login");
        dispatch(logout());
        console.log(user);
      });
      return;
    }
    setIsLoading(false);
  }, []);

  return (
    isLoading?<> Loading...</>:
    <div className="d-flex">
      {/* Sidebar */}
      <nav
        className={`sidebar bg-dark text-light `}
        id="offcanvasExample"
        aria-labelledby="offcanvasExampleLabel"
      >
        <h3 className="text-center py-3">
          <Link to="/admin" className="text-light text-decoration-none">
            <i className="bi bi-person-circle"></i>
            <div className="mt-3">Admin Dashboard</div>
          </Link>
        </h3>{" "}
        <ul className="nav flex-column">
          <li className="nav-item">
            <Link to="dustbins" className="nav-link text-light">
              <i className="bi bi-trash3 me-2"></i> Dustbins
            </Link>
          </li>
          <li className="nav-item">
            <Link to="events" className="nav-link text-light">
              <i className="bi bi-calendar-event me-2"></i> Events
            </Link>
          </li>
          <li className="nav-item">
            <Link to="users" className="nav-link text-light">
              <i className="bi bi-people me-2"></i> Users
            </Link>
          </li>
          <li className="nav-item">
            <Link to="volunteers" className="nav-link text-light">
              <i className="bi bi-person-lines-fill me-2"></i> Volunteers
            </Link>
          </li>
          <li className="nav-item">
            <Link to="complaints" className="nav-link text-light">
              <i className="bi bi-exclamation-circle me-2"></i> Complaints
            </Link>
          </li>
        </ul>
      </nav>

      {/* Main Content */}
      <div className="main-content flex-grow-1 bg-light">
        <Outlet />
      </div>
    </div>
  );
}
