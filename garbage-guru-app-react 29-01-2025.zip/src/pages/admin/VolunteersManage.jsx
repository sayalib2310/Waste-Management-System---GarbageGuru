import React, { useEffect, useState } from "react";
import { deleteVolunteer, getVolunteers } from "../../api-request/admin-request";
import { flattenObject } from "../../utils/utils";
import { getEventsByVolunteerId } from "../../api-request/event-request";
import { Form, Modal, Table } from "react-bootstrap";
import Swal from "sweetalert2";
import { getAddressCategoryStatusList } from "../../api-request/user-request";
import { useForm } from "react-hook-form";

export default function VolunteersManage() {
  const { register, handleSubmit, setValue, reset } = useForm();
  const [volunteers, setVolunteers] = useState([]);
  const [events, setEvents] = useState([]);
  const [currentVolunteer, setCurrentVolunteer] = useState(null);
  const [areas, setAreas] = useState([]);
  const [showModal, setShowModal] = useState(false);

  const handleCloseModal = () => setShowModal(false);
  const handleShowModal = () => setShowModal(true);

  // Fetch volunteers and areas
  const fetchVolunteers = async () => {
    try {
      const response = (await getVolunteers()).data.map((data) => flattenObject(data));
      const volunteersData = response;
      const basicData = (await getAddressCategoryStatusList()).data;
      setVolunteers(volunteersData);

      setAreas(basicData.address);
    } catch (error) {
      Swal.fire("Error", "Failed to fetch volunteers", "error");
    }
  };

  useEffect(() => {
    fetchVolunteers();
  }, []);

  // View volunteer details and associated events
  const handleViewVolunteer = async (volunteer) => {
    try {
      const response = await getEventsByVolunteerId(volunteer.volunteerId);
      setEvents(response.data);
      setCurrentVolunteer(volunteer);

      setValue("firstName", volunteer.firstName);
      setValue("lastName", volunteer.lastName);
      setValue("userName", volunteer.userName);
      setValue("emailId", volunteer.emailId);
      setValue("contactNo", volunteer.contactNo);
      setValue("aadharNo", volunteer.aadharNo);
      setValue("address", volunteer.address);
      setValue("areaId", volunteer["area.areaId"]);
      setValue("department", volunteer.department);
      setValue("purpose", volunteer.purpose);
      setValue("experience", volunteer.experience);

      handleShowModal();
    } catch (error) {
      Swal.fire("Error", "Failed to fetch events", "error");
    }
  };

  // Delete a volunteer
  const handleDeleteVolunteer = (volunteerId) => {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "No, cancel!",
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          await deleteVolunteer(volunteerId);
          Swal.fire("Deleted!", "Volunteer has been deleted.", "success");
          fetchVolunteers();
        } catch (error) {
          Swal.fire("Error", "Failed to delete volunteer", "error");
        }
      }
    });
  };

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between mb-3">
        <h3>Volunteer Management</h3>
        <input
          type="text"
          className="form-control w-25"
          placeholder="Search by Name, Area"
          onChange={(event) => {
            const query = event.target.value.toLowerCase();
            const filtered = volunteers.filter(
              (vol) =>
                vol.firstName.toLowerCase().includes(query) ||
                vol.lastName.toLowerCase().includes(query) ||
                vol["area.areaName"].toLowerCase().includes(query) ||
                !query
            );
            setVolunteers(filtered);
          }}
        />
      </div>

      <Table bordered>
        <thead>
          <tr>
            <th>Name</th>
            <th>Username</th>
            <th>Contact</th>
            <th>Area</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {volunteers.map((volunteer) => (
            <tr key={volunteer.volunteerId}>
              <td>{`${volunteer.firstName} ${volunteer.lastName}`}</td>
              <td>{volunteer.userName}</td>
              <td>{volunteer.contactNo}</td>
              <td>{volunteer["area.areaName"]}</td>
              <td>
                <button className="btn btn-info btn-sm" onClick={() => handleViewVolunteer(volunteer)}>
                  View
                </button>
                <button className="btn btn-danger btn-sm mx-2" onClick={() => handleDeleteVolunteer(volunteer.volunteerId)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>

      {/* Volunteer Details Modal */}
      <Modal size="lg" show={showModal} onHide={handleCloseModal} scrollable>
        <Modal.Header closeButton>
          <Modal.Title>Volunteer Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-2">
              <Form.Label>First Name</Form.Label>
              <Form.Control type="text" disabled {...register("firstName")} />
            </Form.Group>
            <Form.Group className="mb-2">
              <Form.Label>Last Name</Form.Label>
              <Form.Control type="text" disabled {...register("lastName")} />
            </Form.Group>
            <Form.Group className="mb-2">
              <Form.Label>Username</Form.Label>
              <Form.Control type="text" disabled {...register("userName")} />
            </Form.Group>
            <Form.Group className="mb-2">
              <Form.Label>Contact</Form.Label>
              <Form.Control type="text" disabled {...register("contactNo")} />
            </Form.Group>
            <Form.Group className="mb-2">
              <Form.Label>Email</Form.Label>
              <Form.Control type="text" disabled {...register("emailId")} />
            </Form.Group>
            <Form.Group className="mb-2">
              <Form.Label>Address</Form.Label>
              <Form.Control type="text" disabled {...register("address")} />
            </Form.Group>
            <Form.Group className="mb-2">
              <Form.Label>Area</Form.Label>
              <Form.Control type="text" disabled value={currentVolunteer?.["area.areaName"]} />
            </Form.Group>
            <Form.Group className="mb-2">
              <Form.Label>Department</Form.Label>
              <Form.Control type="text" disabled {...register("department")} />
            </Form.Group>
            <Form.Group className="mb-2">
              <Form.Label>Purpose</Form.Label>
              <Form.Control type="text" disabled {...register("purpose")} />
            </Form.Group>
            <Form.Group className="mb-2">
              <Form.Label>Experience</Form.Label>
              <Form.Control type="text" disabled {...register("experience")} />
            </Form.Group>
          </Form>
          {events.length > 0 && (
            <>
              <h5 className="mt-4">Events Participated</h5>
              <Table bordered>
                <thead>
                  <tr>
                    <th>Event Name</th>
                    <th>Description</th>
                    <th>Date</th>
                    <th>Area</th>
                  </tr>
                </thead>
                <tbody>
                  {events.map((event) => (
                    <tr key={event.eventId}>
                      <td>{event.eventName}</td>
                      <td>{event.description}</td>
                      <td>{event.eventDate}</td>
                      <td>{event.area.areaName}</td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </>
          )}
        </Modal.Body>
      </Modal>
    </div>
  );
}
