import React, { useEffect, useState } from "react";
import { deleteUserById, getAddressCategoryStatusList, getAllUsers, updateUserById } from "../../api-request/user-request";
import { flattenObject } from "../../utils/utils";
import { Button, Form, Modal } from "react-bootstrap";
import Swal from "sweetalert2";
import { useForm } from "react-hook-form";

export default function UserManage() {
  const { register, handleSubmit, reset, setValue } = useForm();
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [areas, setAreas] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  // Fetch users and supporting data
  const fetchUsers = async () => {
    try {
      const userData = (await getAllUsers()).data.map((data) => flattenObject(data)); // Replace with API call
      console.log(userData);

      const basicData = (await getAddressCategoryStatusList()).data;
      console.log(basicData);

      setAreas(basicData.address);
      setUsers(userData);
      setFilteredUsers(userData);
    } catch (error) {
      Swal.fire("Error", "Failed to fetch users", "error");
    }
  };

  useEffect(() => {
    fetchUsers(); // Load users on page load
  }, []);

  // Update user
  const handleUpdateUser = async (data) => {
    console.log(data);
    
    const response = await updateUserById(data?.userId, {
      role: {
        roleId: 1,
        roleName: "ROLE_USER",  
      },
      ...data,
    }); // Replace with API call
    if (response.status) {
      Swal.fire("Success", "User updated successfully", "success");
      fetchUsers(); // Refresh list
      reset();
      handleClose();
    } else {
      Swal.fire("Error", "Failed to update user", "error");
    }
  };

  // Delete user
  const handleDeleteUser = (userId) => {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
      cancelButtonText: "No, cancel!",
    }).then(async (result) => {
      if (result.isConfirmed) {
        const response = await deleteUserById(userId); // Replace with API call
        if (response.status) {
          Swal.fire("Deleted!", "User has been deleted.", "success");
          fetchUsers(); // Refresh list
        } else {
          Swal.fire("Error", "Failed to delete user", "error");
        }
      }
    });
  };

  // Set form values for edit
  const handleEditUser = (user) => {
    setCurrentUser(user);
    setValue("userId", user.userId);
    setValue("firstName", user.firstName);
    setValue("lastName", user.lastName);
    setValue("userName", user.userName);
    setValue("emailId", user.emailId);
    setValue("password", user.password);
    setValue("contactNo", user.contactNo);
    setValue("aadharNo", user.aadharNo);
    setValue("address", user.address);
    setValue("areaId", user["area.areaId"]);
    setValue("roleId", user["role.roleId"]);
    handleShow();
  };

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between mb-3">
        <input
          type="text"
          className="form-control w-25"
          placeholder="Search by Name, Email, or Area"
          onChange={(e) => {
            const query = e.target.value.toLowerCase();
            const filtered = users.filter(
              (user) =>
                user.firstName.toLowerCase().includes(query) ||
                user.emailId.toLowerCase().includes(query) ||
                user["area.areaName"].toLowerCase().includes(query)
            );
            setFilteredUsers(filtered);
          }}
        />
      </div>

      <table className="table table-bordered">
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Contact</th>
            <th>Area</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filteredUsers.map((user) => (
            <tr key={user.userId}>
              <td>{`${user.firstName} ${user.lastName}`}</td>
              <td>{user.emailId}</td>
              <td>{user.contactNo}</td>
              <td>{user["area.areaName"]}</td>

              <td>
                <button className="btn btn-sm btn-info" onClick={() => handleEditUser(user)}>
                  Edit
                </button>
                <button className="btn btn-sm btn-danger mx-2" onClick={() => handleDeleteUser(user.userId)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Modal for Add and Edit */}
      <Modal show={show} onHide={handleClose} backdrop="static" scrollable={true} keyboard={false}>
        <Modal.Header closeButton>
          <Modal.Title>{currentUser ? "Update User" : "Add User"}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleSubmit(currentUser ? handleUpdateUser : () => {})}>
            <Form.Control type="hidden" {...register("userId")} />

            <Form.Group className="mb-2">
              <Form.Label>First Name</Form.Label>
              <Form.Control {...register("firstName", { required: true })} />
            </Form.Group>

            <Form.Group className="mb-2">
              <Form.Label>Last Name</Form.Label>
              <Form.Control {...register("lastName", { required: true })} />
            </Form.Group>

            <Form.Group className="mb-2">
              <Form.Label>Email</Form.Label>
              <Form.Control type="email" {...register("emailId", { required: true })} />
            </Form.Group>

            <Form.Group className="mb-2">
              <Form.Label>Contact</Form.Label>
              <Form.Control {...register("contactNo", { required: true })} />
            </Form.Group>

            <Form.Group className="mb-2">
              <Form.Label>Address</Form.Label>
              <Form.Control {...register("address", { required: true })} />
            </Form.Group>

            <Form.Group className="mb-2">
              <Form.Label>Area</Form.Label>
              <Form.Select {...register("areaId", { required: true })}>
                <option value="">Select Area</option>
                {areas.map((area) => (
                  <option key={area.areaId} value={area.areaId}>
                    {area.areaName}
                  </option>
                ))}
              </Form.Select>
            </Form.Group>

            <Button type="submit" variant="primary">
              Save
            </Button>
          </Form>
        </Modal.Body>
      </Modal>
    </div>
  );
}
