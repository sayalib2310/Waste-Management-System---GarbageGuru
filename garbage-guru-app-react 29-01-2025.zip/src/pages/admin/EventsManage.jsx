import React, { useEffect, useState } from 'react'
import { getAllEvents } from '../../api-request/event-request';
import { flattenObject } from '../../utils/utils';
import { createEvent, deleteEvent, getEventEnrollments, updateEvent } from '../../api-request/admin-request';
import { Button, Form, Modal, Table } from 'react-bootstrap';
import Swal from 'sweetalert2';
import { getAddressCategoryStatusList } from '../../api-request/user-request';
import { useForm } from 'react-hook-form';

export default function EventsManage() {
  const { register, handleSubmit, reset, setValue } = useForm();
  const [events, setEvents] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [currentEvent, setCurrentEvent] = useState(null);
  const [areas, setAreas] = useState([]);
  const [show, setShow] = useState(false);
  const [volunteers, setVolunteers] = useState([]);
  const [viewMode, setViewMode] = useState(false);

  const handleClose = () => {
    setShow(false);
    setViewMode(false);
  };
  const handleShow = () => setShow(true);

  const fetchEvents = async () => {
    try {
      const eventList = (await getAllEvents()).data.map((data)=>flattenObject(data));
      const basicData = (await getAddressCategoryStatusList()).data; // Assuming getAddressList fetches the areas
      setEvents(eventList);
      setFiltered(eventList);
      setAreas(basicData.address);
    } catch (error) {
      Swal.fire("Error", "Failed to fetch events", "error");
    }
  };

  useEffect(() => {
    fetchEvents(); // Load events on page load
  }, []);

  const handleAddEvent = async (data) => {
    const requestBody = transformEventObject(data);
    const response = await createEvent(requestBody);
    console.log(response);
    
    if (response.status) {
      Swal.fire("Success", "Event added successfully", "success");
      fetchEvents();
      reset();
      handleClose();
    } else {
      Swal.fire("Error", "Failed to add event", "error");
    }
  };

  const handleUpdateEvent = async (data) => {
    const response = await updateEvent(currentEvent.eventId, data);
    if (response.status) {
      Swal.fire("Success", "Event updated successfully", "success");
      fetchEvents();
      reset();
      handleClose();
    } else {
      Swal.fire("Error", response.message, "error");
    }
  };

  const handleDeleteEvent = (eventId) => {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes, delete it!",
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          await deleteEvent(eventId);
          Swal.fire("Deleted!", "Event has been deleted.", "success");
          fetchEvents();
        } catch (error) {
          Swal.fire("Error", "Failed to delete event", "error");
        }
      }
    });
  };

  const handleViewEvent = async (event) => {
    setCurrentEvent(event);
    const volunteerList = (await getEventEnrollments(event.eventId)).data;
    setVolunteers(volunteerList);
    setViewMode(true);
    handleShow();
  };

  const transformEventObject = (input) => {
    return {
      eventName: input.eventName,
      description: input.description,
      eventDate: input.eventDate,
      maxParticipants: parseInt(input.maxParticipants, 10),
      areaId: parseInt(input.areaId, 10),
    };
  };

  const handleEditEvent = (event) => {
    setCurrentEvent(event);
    setValue("eventId", event.eventId);
    setValue("eventName", event.eventName);
    setValue("description", event.description);
    setValue("eventDate", event.eventDate);
    setValue("maxParticipants", event.maxParticipants);
    setValue("areaId", event["area.areaId"]);
    handleShow();
  };

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between mb-3">
        <button
          className="btn btn-primary"
          onClick={() => {
            handleShow();
            setCurrentEvent(null);
            reset();
          }}
        >
          Add Event
        </button>
        <input
          type="text"
          className="form-control w-25"
          placeholder="Search by Name or Area"
          onChange={(event) => {
            const query = event.target.value.toLowerCase();
            const filteredEvents = events.filter(
              (event) =>
                event.eventName.toLowerCase().includes(query) ||
                event["area.areaName"].toLowerCase().includes(query) ||
                !query
            );
            setFiltered(filteredEvents);
          }}
        />
      </div>

      <Table bordered hover>
        <thead>
          <tr>
            <th>Event Name</th>
            <th>Description</th>
            <th>Event Date</th>
            <th>Max Participants</th>
            <th>Remaining Participants</th>
            <th>Area</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {filtered.map((event) => (
            <tr key={event.eventId}>
              <td>{event.eventName}</td>
              <td>{event.description}</td>
              <td>{event.eventDate}</td>
              <td>{event.maxParticipants}</td>
              <td>{event.remainingParticipants}</td>
              <td>{event["area.areaName"]}</td>
              <td className='align-middle'>
                <div className='h-100 d-flex'>
                <button className="btn btn-sm btn-info" onClick={() => handleViewEvent(event)}>
                  View
                </button>
                <button className="btn btn-sm btn-warning mx-2" onClick={() => handleEditEvent(event)}>
                  Edit
                </button>
                <button className="btn btn-sm btn-danger" onClick={() => handleDeleteEvent(event.eventId)}>
                  Delete
                </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>

      {/* Modal for Add, Edit, and View */}
      <Modal show={show} onHide={handleClose} backdrop="static" scrollable={true} keyboard={false}>
        <Modal.Header closeButton>
          <Modal.Title>
            {viewMode ? "Event Details" : currentEvent ? "Update Event" : "Add Event"}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {viewMode ? (
            <>
              <p><strong>Name:</strong> {currentEvent.eventName}</p>
              <p><strong>Description:</strong> {currentEvent.description}</p>
              <p><strong>Date:</strong> {currentEvent.eventDate}</p>
              <p><strong>Area:</strong> {currentEvent["area.areaName"]}</p>
              
              <p><strong>Volunteers:</strong></p>
              {volunteers.length>0? <ul>
                {volunteers.map((volunteer) => (
                  <li key={volunteer.volunteerId}>
                    {volunteer.firstName} {volunteer.lastName} - {volunteer.contactNo}
                  </li>
                ))}
              </ul>: <p>No Volunteer Participated</p>}
            </>
          ) : ( 
            <Form onSubmit={handleSubmit(currentEvent ? handleUpdateEvent : handleAddEvent)}>
              <Form.Control type="hidden" {...register("eventId")} />
              <Form.Group className="mb-2">
                <Form.Label>Event Name</Form.Label>
                <Form.Control type="text" {...register("eventName", { required: true })} />
              </Form.Group>
              <Form.Group className="mb-2">
                <Form.Label>Description</Form.Label>
                <Form.Control as="textarea" rows={3} {...register("description", { required: true })} />
              </Form.Group>
              <Form.Group className="mb-2">
                <Form.Label>Event Date</Form.Label>
                <Form.Control type="date" {...register("eventDate", { required: true })} />
              </Form.Group>
              <Form.Group className="mb-2">
                <Form.Label>Max Participants</Form.Label>
                <Form.Control type="number" {...register("maxParticipants", { required: true })} />
              </Form.Group>
              <Form.Group className="mb-2">
                <Form.Label>Area</Form.Label>
                <Form.Select {...register("areaId", { required: true })}>
                  <option value="">Select Area</option>
                  {areas.map((area) => (
                    <option key={area.areaId} value={area.areaId}>
                      {area.areaName}
                    </option>
                  ))}
                </Form.Select>
              </Form.Group>
              <Button type="submit" variant="primary">
                Save
              </Button>
            </Form>
          )}
        </Modal.Body>
      </Modal>
    </div>
  );
}
