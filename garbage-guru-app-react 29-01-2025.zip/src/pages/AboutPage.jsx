import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom';

import image1 from "../assets/clean-india-english-meaning-swachh-600nw-2043162371.webp";
import image2 from '../assets/02modi-swacch2.webp'

export default function AboutPage() {
  const navigate = useNavigate();

  useEffect(() => {
    document.getElementById("container").scrollTo(0, 0);

}, []);
  const handleRegister = () => {
    navigate("/volunteer-registration"); // Replace with your volunteer registration page route
  };
  return (
    <div className="container my-5">
      {/* Section 1: Hero Section */}
      <div className="mb-5 text-center">
        <h1 className="display-4 fw-bold">About Garbage Guru</h1>
        <p className="lead">
          Empowering communities with smart waste management solutions for a cleaner, greener future.
        </p>
      </div>

      <hr className="featurette-divider" />


      {/* Section 2: Our Mission */}
      <div className="mb-5">
        <h2 className="text-center mb-4">Our Mission</h2>
        <div className="row align-items-center">
          <div className="col-md-6">
            <p>
              At Garbage Guru, our mission is to revolutionize the way cities manage waste.
              We aim to create sustainable systems that reduce environmental impact, improve
              community health, and promote a culture of recycling and reusing.
            </p>
            <p>
              By combining technology, innovation, and community participation, we are driving
              the change toward smarter and cleaner cities.
            </p>
          </div>
          <div className="col-md-6 text-center">
            <img
              src={image1}
              alt="Our Mission"
              className="img-fluid rounded  w-50"
            />
          </div>
        </div>
      </div>

      <hr className="featurette-divider" />

      {/* Section 3: What We Do */}
      <div className="mb-5">
        <h2 className="text-center mb-4">What We Do</h2>
        <div className="row">
          <div className="col-md-4">
            <div className="card shadow-sm h-100">
              <div className="card-body">
                <h5 className="card-title">Smart Dustbins</h5>
                <p className="card-text">
                  We implement smart dustbins across cities to monitor garbage levels and optimize
                  waste collection schedules.
                </p>
              </div>
            </div>
          </div>
          <div className="col-md-4">
            <div className="card shadow-sm h-100">
              <div className="card-body">
                <h5 className="card-title">Recycling Initiatives</h5>
                <p className="card-text">
                  Our programs focus on promoting recycling by educating communities and providing
                  easy-to-access recycling points.
                </p>
              </div>
            </div>
          </div>
          <div className="col-md-4">
            <div className="card shadow-sm h-100">
              <div className="card-body">
                <h5 className="card-title">Community Engagement</h5>
                <p className="card-text">
                  We collaborate with citizens, schools, and businesses to host clean-up drives,
                  workshops, and awareness campaigns.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <hr className="featurette-divider" />

      {/* Section 4: Our Impact */}
      <div className="mb-5">
        <h2 className="text-center mb-4">Our Impact</h2>
        <div className="row align-items-center">
          <div className="col-md-6 text-center">
            <img
              src={image2}
              alt="Our Impact"
              className="img-fluid rounded"
            />
          </div>
          <div className="col-md-6">
            <p>
              Since our inception, Garbage Guru has made a significant impact on urban waste
              management:
            </p>
            <ul className="list-group list-group-flush">
              <li className="list-group-item">Reduced landfill waste by 30% in partnered cities.</li>
              <li className="list-group-item">Organized over 100 clean-up drives with thousands of volunteers.</li>
              <li className="list-group-item">Educated over 50,000 people on sustainable living practices.</li>
              <li className="list-group-item">Enabled smarter waste collection with real-time monitoring technology.</li>
            </ul>
          </div>
        </div>
      </div>

      <hr className="featurette-divider" />


      {/* Section 5: Call to Action */}
      <div className="text-center py-4 bg-light rounded shadow">
        <h3 className="fw-bold">Join Us on Our Journey</h3>
        <p className="lead">
          Together, we can create a cleaner, healthier, and more sustainable future. Be a part of
          the change!
        </p>
        <button className="btn btn-primary btn-lg" onClick={handleRegister}>Get Involved</button>
      </div>
    </div>
  );

  
};
