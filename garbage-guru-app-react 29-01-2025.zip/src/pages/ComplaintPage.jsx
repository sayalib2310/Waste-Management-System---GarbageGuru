import React, { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { flattenObject } from '../utils/utils';
import { getDustbins } from '../api-request/dustbin-request';
import { createComplaint, getAddressCategoryStatusList } from '../api-request/user-request';
import Swal from 'sweetalert2';

export default function ComplaintPage() {
    const { register, handleSubmit, watch,reset, formState: { errors } } = useForm();
    const navigate = useNavigate();
    const user = useSelector((state) => state.user.userInfo); // Assuming user info is stored in Redux
    const [dustbins, setDustbins] = useState([]);
    const [areas, setAreas] = useState([]);
    const [isOtherIssue, setIsOtherIssue] = useState(false);
  
    // Redirect to registration page if user is not logged in
    useEffect(() => {
      if (!user?.firstName) {
        navigate("/login");
      }
    }, [user, navigate]);
  
    // Fetch dustbin and area lists from APIs
    useEffect( () =>  {
        fetchData();
    }, []);
  
    async function fetchData(params) {
       try {
         const mockData = (await getDustbins()).data.map((data) =>
             flattenObject(data)
           );
       
           const basicData =  (await getAddressCategoryStatusList()).data;
           
           setAreas(basicData.address);
           setDustbins(mockData); 
       } catch (error) {
        console.log(error);
        
       }
    }
    const onSubmit = async (data) => {
      const complaintObject = {
        userId: user?.userId, // Assuming user ID is in Redux state
        issue: data.issue === "Other" ? data.otherIssue : data.issue,
        address: data.address,
        areaId: parseInt(data.areaId, 10),
        dustbinNo: parseInt(data.dustbinNo, 10),
        createdAt: new Date().toISOString(),
      };
      console.log("Complaint Object:", complaintObject);


      const response = await createComplaint(complaintObject);
      
          console.log(response.data);
          console.log(user);
      
          if (response.status) {
            Swal.fire("Success", "Complaint Registered Successfully! <br/> Track Status From Dashboard", "success").then(async () => {
                reset();
            });
          } else {
            Swal.fire("Error", ` failed! <br/>${response.message}`, "error");
          }
    };
  
    const watchIssue = watch("issue", "");
  
    useEffect(() => {
      setIsOtherIssue(watchIssue === "Other");
    }, [watchIssue]);
  
    return (
      <div className="d-flex justify-content-center align-items-center vh-100">
        <div className="border p-4 rounded bg-light" style={{ width: "500px", boxShadow: "0px 4px 6px rgba(0,0,0,0.1)" }}>
          <h3 className="text-center mb-4">Complaint Form</h3>
          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="mb-3">
              <label htmlFor="name" className="form-label">Name</label>
              <input
                type="text"
                id="name"
                className="form-control"
                defaultValue={`${user?.firstName} ${user?.lastName}`}
                disabled={!!user?.firstName}
                {...register("name", { required: "Name is required" })}
              />
              {errors.name && <small className="text-danger">{errors.name.message}</small>}
            </div>
            <div className="mb-3">
              <label htmlFor="dustbinNo" className="form-label">Dustbin No</label>
              <select
                id="dustbinNo"
                className="form-select"
                {...register("dustbinNo", { required: "Please select a dustbin" })}
              >
                <option value="">Select Dustbin</option>
                {dustbins.map((dustbin) => (
                  <option key={dustbin.dustNo} value={dustbin.dustNo}>
                    {dustbin.dustNo}
                  </option>
                ))}
              </select>
              {errors.dustbinNo && <small className="text-danger">{errors.dustbinNo.message}</small>}
            </div>
            <div className="mb-3">
              <label htmlFor="areaId" className="form-label">Area</label>
              <select
                id="areaId"
                className="form-select"
                {...register("areaId", { required: "Please select an area" })}
              >
                <option value="">Select Area</option>
                {areas.map((area) => (
                  <option key={area.areaId} value={area.areaId}>
                    {area.areaName}
                  </option>
                ))}
              </select>
              {errors.areaId && <small className="text-danger">{errors.areaId.message}</small>}
            </div>
            <div className="mb-3">
              <label htmlFor="issue" className="form-label">Issue</label>
              <select
                id="issue"
                className="form-select"
                {...register("issue", { required: "Please select an issue" })}
              >
                <option value="">Select Issue</option>
                <option value="Overflowing">Overflowing</option>
                <option value="Broken Lid">Broken Lid</option>
                <option value="Not Collected">Not Collected</option>
                <option value="Other">Other</option>
              </select>
              {errors.issue && <small className="text-danger">{errors.issue.message}</small>}
            </div>
            {isOtherIssue && (
              <div className="mb-3">
                <label htmlFor="otherIssue" className="form-label">Other Issue</label>
                <input
                  type="text"
                  id="otherIssue"
                  className="form-control"
                  {...register("otherIssue", { required: "Please specify the issue" })}
                />
                {errors.otherIssue && <small className="text-danger">{errors.otherIssue.message}</small>}
              </div>
            )}
            <div className="mb-3">
              <label htmlFor="address" className="form-label">Address</label>
              <textarea
                id="address"
                className="form-control"
                rows="3"
                {...register("address", { required: "Address is required" })}
              ></textarea>
              {errors.address && <small className="text-danger">{errors.address.message}</small>}
            </div>
            <div className="d-grid">
              <button type="submit" className="btn btn-primary">Submit Complaint</button>
            </div>
          </form>
        </div>
      </div>
    );
}
