
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./components/Layout";
import HomePage from "./pages/HomePage";
import DustbinPage from "./pages/DustbinPage";
import EventPage from "./pages/EventPage";
import VolunteerPage from "./pages/VolunteerPage";
import BlogsPage from "./pages/BlogsPage";
import ContactPage from "./pages/ContactPage";
import ComplaintPage from "./pages/ComplaintPage";
import AboutPage from "./pages/AboutPage";
import LoginPage from "./pages/LoginPage";
import RegistrationPage from "./pages/RegistrationPage";
import VolunteerRegistrationPage from "./pages/VolunteerRegistrationPage";
import NoPage from "./pages/NoPage";
import AdminLayout from "./pages/admin/AdminLayout";
import AdminDashboard from "./pages/admin/AdminDashboard";
import DustbinManage from "./pages/admin/DustbinManage";
import EventsManage from "./pages/admin/EventsManage";
import UserManage from "./pages/admin/UserManage";
import VolunteersManage from "./pages/admin/VolunteersManage";
import ComplaintsManage from "./pages/admin/ComplaintsManage";
import UserDashboard from "./pages/user/UserDashboard";
import UserLayout from "./pages/user/UserLayout";
import UserProfile from "./pages/user/UserProfile";
import UserVolunteerPage from "./pages/user/UserVolunteerPage";
import UserComplaintPage from "./pages/user/UserComplaintPage";



function App() {
  return ( 
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<HomePage />} />
          <Route path="dustbins" element={<DustbinPage />} />
          <Route path="events" element={<EventPage />} />
          <Route path="volunteers" element={<VolunteerPage />} />
          <Route path="blogs" element={<BlogsPage />} />
          <Route path="contacts" element={<ContactPage />} />
          <Route path="complaint" element={<ComplaintPage />} />
          <Route path="about" element={<AboutPage />} />
          <Route path="login" element={<LoginPage />} />
          <Route path="register" element={<RegistrationPage />} />
          <Route path="volunteer-registration" element={<VolunteerRegistrationPage />} />
          <Route path="*" element={<NoPage />} />
          <Route path="admin" element={<AdminLayout />}>
            <Route index element={<AdminDashboard />} />
            <Route path="dustbins" element={<DustbinManage />} />
            <Route path="events" element={<EventsManage />} />
            <Route path="users" element={<UserManage />} />
            <Route path="volunteers" element={<VolunteersManage />} />
            <Route path="complaints" element={<ComplaintsManage />} />
            <Route path="*" element={<NoPage />} />
          </Route>
          <Route path="user" element={<UserLayout />}>
            <Route index  element={<UserDashboard />} />
            <Route path="profile"  element={<UserProfile />} />
            <Route path="complaints"  element={<UserComplaintPage />} />
            <Route path="volunteers"  element={<UserVolunteerPage />} />
            <Route path="*" element={<NoPage />} />
          </Route>
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
