package com.garbage_guru.api.dto;

import java.sql.Date;
import com.garbage_guru.api.entity.Address;
import lombok.Data;

@Data
public class EventDto {
    private Long eventId;
    private String eventName;
    private String description;
    private Date eventDate;
    private int maxParticipants;
    private int remainingParticipants;
    private Address area;
}
