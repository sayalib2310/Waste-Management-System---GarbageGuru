package com.garbage_guru.api.dto;

import java.time.LocalDate;

import lombok.Data;


@Data
public class DustbinDto {
    private Long dustbinId;
    private LocalDate allocatedDate;
    private LocalDate lastCleanDate;
    private Integer garbageQtyInKg;
    private Long statusId;
    private String statusName;
    private Long areaId;
    private String areaName;
    private Long categoryId;
    private String categoryName;
    private Long dustNo;
}
