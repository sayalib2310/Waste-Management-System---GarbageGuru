package com.garbage_guru.api.dto;

import java.util.Set;

import com.garbage_guru.api.entity.Address;

import lombok.Data;

@Data
public class VolunteerDto {
    private Long userId;
    private String firstName;
    private String lastName;
    private String userName;
    private String emailId;
    private String password;
    private String contactNo;
    private String aadharNo;
    private String address; 
    private Address area;

    private Long volunteerId;

    private String department;
    private String purpose;
    private String experience;

    private Set<EventDto> events;

}
