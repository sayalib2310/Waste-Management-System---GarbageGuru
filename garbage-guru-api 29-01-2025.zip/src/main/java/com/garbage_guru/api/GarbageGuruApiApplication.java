package com.garbage_guru.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GarbageGuruApiApplication {

	public static void main(String[] args) {

		SpringApplication.run(GarbageGuruApiApplication.class, args);
	}

}
