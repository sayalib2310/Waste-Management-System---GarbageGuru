package com.garbage_guru.api.controller;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.garbage_guru.api.dto.EventDto;
import com.garbage_guru.api.entity.Volunteer;
import com.garbage_guru.api.response.ApiResponse;
import com.garbage_guru.api.service.event.IEventService;
import com.garbage_guru.api.service.volunteer.IVolunteerService;
import com.garbage_guru.api.util.Constants;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/event")
public class EventController {

    private final IEventService eventService;
    private final IVolunteerService volunteerService;
    private final ModelMapper modelMapper;

    @GetMapping
    public ResponseEntity<ApiResponse> getAllEvents() {
        try {

            List<EventDto> list = eventService.getAllEvents().stream().map(
                    t -> {
                        EventDto eventDto = modelMapper.map(t, EventDto.class);
                        eventDto.setRemainingParticipants(t.getMaxParticipants() - t.getVolunteers().size());
                        return eventDto;
                    }).toList();
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, list));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @PostMapping
    public ResponseEntity<ApiResponse> enrollmentEvent(@RequestParam Long volunteerId, @RequestParam Long eventId) {
        try {

            Volunteer volunteer = volunteerService.enrollInEvent(volunteerId, eventId);
            List<EventDto> list = volunteer.getEvents().stream().map(
                    event -> {
                        EventDto eventDto = modelMapper.map(event, EventDto.class);
                        int rem = event.getMaxParticipants() - event.getVolunteers().size();
                        eventDto.setRemainingParticipants(rem);
                        return eventDto;
                    }).toList();
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, list));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @DeleteMapping("/remove/{eventId}/{volunteerId}")
    public ResponseEntity<ApiResponse> removeVolunteerFromEvent(@PathVariable Long eventId,
            @PathVariable Long volunteerId) {
        try {
            eventService.removeVolunteerFromEvent(eventId, volunteerId);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, "Volunteer Removed Successfully"));

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @GetMapping("/volunteer/{volunteerId}")
    public ResponseEntity<ApiResponse> getEventsByVolunteerId(@PathVariable Long volunteerId) {

        try {

            List<EventDto> events = eventService.getEventsByVolunteerId(volunteerId);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, events));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }

    }
}
