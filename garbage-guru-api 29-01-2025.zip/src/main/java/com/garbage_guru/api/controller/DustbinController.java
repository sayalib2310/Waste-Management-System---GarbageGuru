package com.garbage_guru.api.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.garbage_guru.api.dto.DustbinDto;
import com.garbage_guru.api.entity.Dustbin;
import com.garbage_guru.api.response.ApiResponse;
import com.garbage_guru.api.service.dustbin.DustbinService;
import com.garbage_guru.api.util.Constants;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/dustbins")
public class DustbinController {
    private final DustbinService dustbinService;

    // Create Dustbin
    @PostMapping
    public ResponseEntity<ApiResponse> createDustbin(@RequestBody DustbinDto dustbinDto) {
        try {
            Dustbin createdDustbin = dustbinService.createDustbin(dustbinDto);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, createdDustbin));

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));

        }
    }

    @GetMapping
    public ResponseEntity<ApiResponse> getDustbins() {
        try {
            List<Dustbin> list = dustbinService.getAllDustbins();
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, list));

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));

        }
    }

    // Update Dustbin
    @PutMapping("/{dustbinId}")
    public ResponseEntity<ApiResponse> updateDustbin(@PathVariable Long dustbinId, @RequestBody DustbinDto dustbinDto) {
        try {
            Dustbin updatedDustbin = dustbinService.updateDustbin(dustbinId, dustbinDto);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, "Updated Successfully ", updatedDustbin));

        } catch (Exception e) {
            e.printStackTrace();

            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));

        }
    }

    // Delete Dustbin
    @DeleteMapping("/{dustbinId}")
    public ResponseEntity<ApiResponse> deleteDustbin(@PathVariable Long dustbinId) {
        try {
            dustbinService.deleteDustbin(dustbinId);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, "Dustbin Deleted Successfully"));

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));

        }
    }

    // Get Dustbin by ID
    @GetMapping("/{dustbinId}")
    public ResponseEntity<ApiResponse> getDustbinById(@PathVariable Long dustbinId) {
        try {
            Dustbin dustbin = dustbinService.getDustbinById(dustbinId);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, dustbin));

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));

        }
    }

    // Get Dustbins by Number
    @GetMapping("/number/{dustNo}")
    public ResponseEntity<ApiResponse> getDustbinsByNumber(@PathVariable Long dustNo) {
        try {
            Dustbin dustbins = dustbinService.getDustbinsByNumber(dustNo);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, dustbins));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));

        }

    }

    // Get Dustbins by Area
    @GetMapping("/area/{areaId}")
    public ResponseEntity<ApiResponse> getDustbinsByArea(@PathVariable Long areaId) {
        try {
            List<Dustbin> dustbins = dustbinService.getDustbinsByArea(areaId);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, dustbins));

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));

        }

    }

    // Get Dustbins by Category
    @GetMapping("/category/{categoryId}")
    public ResponseEntity<ApiResponse> getDustbinsByCategory(@PathVariable Long categoryId) {
        try {
            List<Dustbin> dustbins = dustbinService.getDustbinsByCategory(categoryId);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, dustbins));

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));

        }
    }
}
