package com.garbage_guru.api.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.garbage_guru.api.dto.VolunteerDto;
import com.garbage_guru.api.entity.Complaint;
import com.garbage_guru.api.entity.Event;
import com.garbage_guru.api.enums.ComplaintStatus;
import com.garbage_guru.api.request.CreateEventRequest;
import com.garbage_guru.api.response.ApiResponse;
import com.garbage_guru.api.service.complaint.IComplaintService;
import com.garbage_guru.api.service.event.IEventService;
import com.garbage_guru.api.service.volunteer.IVolunteerService;
import com.garbage_guru.api.util.Constants;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;

@RequiredArgsConstructor
@RestController
@RequestMapping("/admin")
public class AdminController {

    private final IEventService eventService;
    private final IVolunteerService volunteerService;
    private final IComplaintService complaintService;

    final ModelMapper modelMapper;

    @PostMapping("/event")
    public ResponseEntity<ApiResponse> createNewEvent(@RequestBody CreateEventRequest request) {
        try {
            Event newEvent = eventService.createEvent(request);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, newEvent));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @PutMapping("/event/{id}")
    public ResponseEntity<ApiResponse> updateEvent(@PathVariable Long id, @RequestBody CreateEventRequest request) {

        try {
            Event newEvent = eventService.updateEvent(id, request);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, newEvent));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @DeleteMapping("/event/{id}")
    public ResponseEntity<ApiResponse> deleteEvent(@PathVariable Long id) {

        try {
            eventService.deleteEvent(id);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, "Event Deleted Successfully"));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @GetMapping("/event/{eventId}/enrollments")
    public ResponseEntity<ApiResponse> getVolunteersByEventId(@PathVariable Long eventId) {
        try {
            List<VolunteerDto> volunteers = eventService.getVolunteersByEventId(eventId);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, volunteers));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }

    }

    @GetMapping("/volunteers")
    public ResponseEntity<ApiResponse> getAllVolunteers() {
        try {
            List<VolunteerDto> volunteers = volunteerService.getAllVolunteers().stream().map(
                    volunteer -> {
                        VolunteerDto volunteerDto = modelMapper.map(volunteer.getUser(), VolunteerDto.class);
                        volunteerDto.setVolunteerId(volunteer.getVolunteerId());
                        volunteerDto.setDepartment(volunteer.getDepartment());
                        volunteerDto.setPurpose(volunteer.getPurpose());
                        volunteerDto.setExperience(volunteer.getExperience());
                        volunteerDto.setEvents(eventService.getEventsByVolunteerId(volunteer.getVolunteerId()).stream()
                                .collect(Collectors.toSet()));

                        return volunteerDto;
                    }).toList();
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, volunteers));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }

    }

    @DeleteMapping("/volunteers/{id}")
    public ResponseEntity<ApiResponse> deleteVolunteer(@PathVariable Long id) {
        try {
            volunteerService.deleteVolunteer(id);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, "Volunteer Deleted Successfully"));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }

    }

    @GetMapping
    public ResponseEntity<ApiResponse> test() {
        return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, "Admin Api Working"));
    }

  

    @PutMapping("/complaints/{id}/status")
    public ResponseEntity<ApiResponse> changeComplaintStatus(
            @PathVariable Long id,
            @RequestParam ComplaintStatus status) {
        try {
            Complaint updatedComplaint = complaintService.changeStatus(id, status);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, updatedComplaint));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @GetMapping("/complaints/{id}")
    public ResponseEntity<ApiResponse> getComplaintById(@PathVariable Long id) {
        try {
            Complaint complaint = complaintService.getComplaintById(id);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, complaint));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

   

    @DeleteMapping("/complaints/{id}")
    public ResponseEntity<ApiResponse> deleteComplaint(@PathVariable Long id) {
        try {
            complaintService.deleteComplaint(id);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, "Complaint deleted successfully"));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @GetMapping("/complaints")
    public ResponseEntity<ApiResponse> getAllComplaints() {
        try {
            List<Complaint> complaints = complaintService.getAllComplaints();
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, complaints));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }
}
