package com.garbage_guru.api.controller;

import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.garbage_guru.api.dto.UserDto;
import com.garbage_guru.api.dto.VolunteerDto;
import com.garbage_guru.api.entity.Address;
import com.garbage_guru.api.entity.Complaint;
import com.garbage_guru.api.entity.User;
import com.garbage_guru.api.entity.Volunteer;
import com.garbage_guru.api.repository.VolunteerRepository;
import com.garbage_guru.api.request.CreateComplaintRequest;
import com.garbage_guru.api.request.CreateUserRequest;
import com.garbage_guru.api.request.CreateVolunteerRequest;
import com.garbage_guru.api.request.UserLoginRequest;
import com.garbage_guru.api.response.ApiResponse;
import com.garbage_guru.api.service.address.IAddressService;
import com.garbage_guru.api.service.complaint.IComplaintService;
import com.garbage_guru.api.service.role.IRoleService;
import com.garbage_guru.api.service.user.IUserService;
import com.garbage_guru.api.service.volunteer.IVolunteerService;
import com.garbage_guru.api.util.Constants;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@RestController
@RequestMapping("/users")
public class UserController {

    private final IUserService userService;
    private final IRoleService roleService;
    private final IVolunteerService volunteerService;
    private final IAddressService addressService;
    private final IComplaintService complaintService;
    final VolunteerRepository volunteerRepository;
    final ModelMapper modelMapper;

    private final Logger logger = Logger.getLogger(getClass().getName());

    @PostMapping
    public ResponseEntity<ApiResponse> createUser(@RequestBody CreateUserRequest request) {
        try {
            User user = new User();
            user.setFirstName(request.getFirstName());
            user.setLastName(request.getLastName());
            user.setUserName(request.getUserName());
            user.setEmailId(request.getEmailId());
            user.setPassword(request.getPassword());
            user.setContactNo(request.getContactNo());
            user.setAadharNo(request.getAadharNo());
            user.setAddress(request.getAddress());
            Address address = addressService.getAddressById(request.getAreaId()).get();
            user.setArea(address);
            user.setRole(roleService.getRoleById(1L));

            User createdUser = userService.createUser(user);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, createdUser));
        } catch (Exception e) {
            logger.info(e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }

    }

    // Update User
    @PutMapping("/{userId}")
    public ResponseEntity<ApiResponse> updateUser(@PathVariable Long userId, @RequestBody CreateUserRequest request) {
        try {
            User user = new User();
            user.setFirstName(request.getFirstName());
            user.setLastName(request.getLastName());
            user.setUserName(request.getUserName());
            user.setEmailId(request.getEmailId());
            user.setPassword(request.getPassword());
            user.setContactNo(request.getContactNo());
            user.setAadharNo(request.getAadharNo());
            user.setAddress(request.getAddress());
            Address address = addressService.getAddressById(request.getAreaId()).get();
            user.setArea(address);
            user.setRole(roleService.getRoleById(1L));
            User updatedUser = userService.updateUser(userId, user);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, updatedUser));
        } catch (Exception e) {

            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    // Delete User
    @DeleteMapping("/{userId}")
    public ResponseEntity<ApiResponse> deleteUser(@PathVariable Long userId) {
        try {
            userService.deleteUser(userId);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, "User Deleted Successfully"));

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    // Get User by ID
    @GetMapping("/{userId}")
    public ResponseEntity<ApiResponse> getUserById(@PathVariable Long userId) {
        try {

            User user = userService.getUserById(userId);

            Optional<Volunteer> optionalVolunteer = volunteerRepository.findByUserUserId(user.getUserId());
            UserDto userDto = modelMapper.map(user, UserDto.class);

            UserDto userDto1 = optionalVolunteer.map(volunteer -> {
                userDto.setVolunteerId(volunteer.getVolunteerId());
                userDto.setVolunteer(true);
                return userDto;
            }).orElseGet(() -> {
                userDto.setVolunteer(false);
                return userDto;
            });

            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, userDto1));

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @GetMapping("/address-category-status")
    public ResponseEntity<ApiResponse> getBasicInfo() {

        return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, userService.getAddressCategoryStatus()));
    }

    // Get All Users
    @GetMapping
    public ResponseEntity<ApiResponse> getAllUsers() {
        try {
            List<User> users = userService.getAllUsers();
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, users));

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    // Login User
    @PostMapping("/login")
    public ResponseEntity<ApiResponse> login(@RequestBody UserLoginRequest request) {
        try {
            UserDto loggedInUser = userService.login(request.getUserName(), request.getPassword());
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, loggedInUser));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @PostMapping("/volunteer")
    public ResponseEntity<ApiResponse> registerVolunteer(@RequestBody CreateVolunteerRequest request) {
        try {
            Volunteer newVolunteer = volunteerService.createVolunteer(request);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, newVolunteer));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @GetMapping("/volunteer/{volunteerId}")
    public ResponseEntity<ApiResponse> getVolunteerDetails(@PathVariable Long volunteerId) {
        try {
            Volunteer volunteer = volunteerService.getVolunteerById(volunteerId).get();
            VolunteerDto volunteerDto = modelMapper.map(volunteer.getUser(), VolunteerDto.class);
            volunteerDto.setVolunteerId(volunteer.getVolunteerId());
            volunteerDto.setDepartment(volunteer.getDepartment());
            volunteerDto.setPurpose(volunteer.getPurpose());
            volunteerDto.setExperience(volunteer.getExperience());

            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, volunteerDto));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

   

    @GetMapping("/")
    public ResponseEntity<ApiResponse> test() {
        return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, "Api Working"));
    }

    @PostMapping("/complaints/create")
    public ResponseEntity<ApiResponse> createComplaint(@RequestBody CreateComplaintRequest request) {
        try {
            Complaint complaint = complaintService.createComplaint(request);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, complaint));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

    @GetMapping("/{userId}/complaints")
    public ResponseEntity<ApiResponse> getComplaintsByUserId(@PathVariable Long userId) {
        try {
            List<Complaint> complaints = complaintService.getComplaintsByUserId(userId);
            return ResponseEntity.ok(new ApiResponse(Constants.SUCCESS, complaints));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApiResponse(Constants.ERROR, e.getMessage()));
        }
    }

}
