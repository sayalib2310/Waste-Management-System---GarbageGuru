package com.garbage_guru.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.garbage_guru.api.entity.Event;
import com.garbage_guru.api.entity.Volunteer;

public interface EventRepository extends JpaRepository<Event, Long> {
    List<Volunteer> findVolunteersByEventId(Long eventId);

    List<Event> findEventsByVolunteersVolunteerId(Long volunteerId);
}
