package com.garbage_guru.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.garbage_guru.api.entity.Address;

public interface AddressRepository extends JpaRepository<Address,Long> {

    boolean existsByAreaName(String areaName);

}
