package com.garbage_guru.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.garbage_guru.api.entity.Event;
import com.garbage_guru.api.entity.Volunteer;

public interface EventEnrollmentsRepository extends JpaRepository<Event, Long> {
    @Query("SELECT v FROM Event e JOIN e.volunteers v WHERE e.eventId = :eventId")
    List<Volunteer> findVolunteersByEventId(@Param("eventId") Long eventId);

    void deleteByVolunteersVolunteerId(Long volunteerId);
}
