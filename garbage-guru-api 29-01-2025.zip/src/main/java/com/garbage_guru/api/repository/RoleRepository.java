package com.garbage_guru.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.garbage_guru.api.entity.Role;

public interface RoleRepository extends JpaRepository<Role,Long> {

    boolean existsByRoleName(String role);

}
