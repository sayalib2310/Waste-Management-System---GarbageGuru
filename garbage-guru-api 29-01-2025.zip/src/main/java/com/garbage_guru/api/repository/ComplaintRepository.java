package com.garbage_guru.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.garbage_guru.api.entity.Complaint;
import com.garbage_guru.api.entity.User;

public interface ComplaintRepository extends JpaRepository<Complaint,Long>{

    List<Complaint> findByUser(User user);

}
