package com.garbage_guru.api.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.garbage_guru.api.entity.User;

public interface UserRepository extends JpaRepository<User,Long>{

    Optional<User> findByUserName(String userName);

    List<User> findByRoleRoleId(long l);

    boolean existsByUserName(String userName);

}
