package com.garbage_guru.api.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.garbage_guru.api.entity.Status;

public interface StatusRepository extends JpaRepository<Status,Long> {

    boolean existsByStatusName(String s);

}
