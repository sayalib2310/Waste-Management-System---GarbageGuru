package com.garbage_guru.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.garbage_guru.api.entity.Dustbin;

public interface DustbinRepository extends JpaRepository<Dustbin,Long>{

    Dustbin findByDustNo(Long dustNo);

    List<Dustbin> findByArea_AreaId(Long areaId);

    List<Dustbin> findByCategory_CategoryId(Long categoryId);

}
