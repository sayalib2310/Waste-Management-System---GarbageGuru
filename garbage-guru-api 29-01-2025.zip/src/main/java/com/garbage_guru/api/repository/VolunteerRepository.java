package com.garbage_guru.api.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.garbage_guru.api.entity.Volunteer;

public interface VolunteerRepository extends JpaRepository<Volunteer,Long>{

    Optional<Volunteer> findByUserUserId(Long userId);

}
