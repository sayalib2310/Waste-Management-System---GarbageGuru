package com.garbage_guru.api.util;


import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import com.garbage_guru.api.entity.Address;
import com.garbage_guru.api.entity.Category;
import com.garbage_guru.api.entity.Role;
import com.garbage_guru.api.entity.Status;
import com.garbage_guru.api.entity.User;
import com.garbage_guru.api.repository.AddressRepository;
import com.garbage_guru.api.repository.CategoryRepository;
import com.garbage_guru.api.repository.RoleRepository;
import com.garbage_guru.api.repository.StatusRepository;
import com.garbage_guru.api.repository.UserRepository;
import com.garbage_guru.api.service.role.IRoleService;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class DataInitializer implements ApplicationListener<ApplicationReadyEvent> {
    final RoleRepository roleRepository;
    final UserRepository userRepository;
    final CategoryRepository categoryRepository;
    final StatusRepository statusRepository;
    final AddressRepository addressRepository;
    final IRoleService roleService;

    @Override
    public void onApplicationEvent(@SuppressWarnings("null") ApplicationReadyEvent event) {
        createRoleIfNotExists();
        createUsersIfNotExists();
        createCategoryAreaStatus();
    }

    private void createRoleIfNotExists() {
        String[] roles = { "USER", "ADMIN" };

        for (String roleName : roles) {
            String role = "ROLE_" + roleName;

            if (roleRepository.existsByRoleName(role)) {
                continue;
            }

            Role roleEntity = new Role();
            roleEntity.setRoleName(role);
            roleRepository.save(roleEntity);
            System.out.println("Role created: " + role);
        }
    }

    private void createUsersIfNotExists() {

        User user = new User();
        user.setFirstName("Admin");
        user.setLastName("Admin");
        user.setUserName("admin");
        user.setEmailId("admin@gmail.com");
        user.setPassword("admin123");
        user.setContactNo("987456321");
        user.setAadharNo("12365478912");
        user.setRole(roleService.getRoleById(2L));

        if (userRepository.existsByUserName(user.getUserName())) {
            return;
        }

        userRepository.save(user);

        System.out.println("User created: " + user.getUserName());

    }

    private void createCategoryAreaStatus() {
        String[] categories = { "General Waste", "Recyclable Waste", "Organic Waste", "Hazardous Waste",
                "E-Waste", "Construction Waste ", "Plastic Waste", "Metal Waste" };

        String[] areas = {
                "Shivajinagar", "Kothrud", "Hinjewadi", "Wakad", "Baner", "Aundh", "Hadapsar", "Viman Nagar", "Kharadi",
                "Kondhwa"
        };
        String[] status = {
                "0-10%", "11-20%", "21-30%", "31-40%", "41-50%", "51-60%", "61-70%", "71-80%", "81-90%",
                "91-100%"
        };

        for (String s : status) {
            if (!statusRepository.existsByStatusName(s)) {
                Status sa = new Status();
                sa.setStatusName(s);
                statusRepository.save(sa);
            }
        }

        for (String categoryName : categories) {
            if (!categoryRepository.existsByCategoryName(categoryName)) {
                Category sa = new Category();
                sa.setCategoryName(categoryName);
                categoryRepository.save(sa);
            }
        }
        for (String areaName : areas) {
            if (!addressRepository.existsByAreaName(areaName)) {
                Address sa = new Address();
                sa.setAreaName(areaName);
                addressRepository.save(sa);
            }
        }

    }

}
