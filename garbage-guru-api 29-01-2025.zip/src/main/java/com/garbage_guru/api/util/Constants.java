package com.garbage_guru.api.util;


public class Constants {
      private Constants() {
            throw new IllegalStateException("Utility class");
      }

      public static final String SUCCESS = "success";
      public static final String FAILED = "failed";
      public static final String ERROR = "error";
}
