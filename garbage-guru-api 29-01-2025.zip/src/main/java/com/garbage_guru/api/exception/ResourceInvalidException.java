package com.garbage_guru.api.exception;

public class ResourceInvalidException extends RuntimeException {
    public ResourceInvalidException(String message){
        super(message);
    }
}