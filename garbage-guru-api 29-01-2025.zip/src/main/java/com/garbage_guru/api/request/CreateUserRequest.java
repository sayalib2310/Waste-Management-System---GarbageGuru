package com.garbage_guru.api.request;

import lombok.Data;

@Data
public class CreateUserRequest {
    private String firstName;
    private String lastName;

    private String userName;

    private String emailId;
    private String password;

    private String contactNo;

    private String aadharNo;

    private Long areaId;
    private String address;

    private Long roleId;
}
