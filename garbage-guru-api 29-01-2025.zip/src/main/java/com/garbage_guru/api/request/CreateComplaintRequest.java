package com.garbage_guru.api.request;

import java.util.Date;

import com.garbage_guru.api.entity.Dustbin;
import lombok.Data;

@Data
public class CreateComplaintRequest {
    private Long userId;

    private String issue;
    private String address;

    private Long areaId;

    private Long dustbinNo;

    private Date createdAt;
}
