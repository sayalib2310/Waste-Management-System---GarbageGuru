package com.garbage_guru.api.request;

import lombok.Data;

@Data
public class CreateVolunteerRequest {
    private Long userId;
    private String department;
    private String purpose;
    private String experience;
}
