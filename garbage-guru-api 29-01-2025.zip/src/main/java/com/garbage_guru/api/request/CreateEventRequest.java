package com.garbage_guru.api.request;

import java.sql.Date;

import lombok.Data;

@Data
public class CreateEventRequest {
    private String eventName;
    private String description;
    private Date eventDate;
    private int maxParticipants;
    private Long areaId;
}
