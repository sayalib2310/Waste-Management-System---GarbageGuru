package com.garbage_guru.api.enums;

public enum ComplaintStatus {
    OPEN, IN_PROGRESS, RESOLVED;
}
