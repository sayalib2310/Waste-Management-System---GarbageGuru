package com.garbage_guru.api.entity;

import java.util.Date;

import com.garbage_guru.api.enums.ComplaintStatus;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "complaint")
public class Complaint {
      @Id
      @GeneratedValue(strategy = GenerationType.IDENTITY)
      private Long complaintId;

      @ManyToOne
      @JoinColumn(name = "user_id")
      private User user;

      private String issue;
      private String address;

      @ManyToOne
      @JoinColumn(name = "area_id")
      private Address area;

      @ManyToOne
      @JoinColumn(name = "dustbin_id")
      private Dustbin dustbin;

      private Date createdAt;

      @Enumerated(EnumType.STRING)
      private ComplaintStatus status;
}
