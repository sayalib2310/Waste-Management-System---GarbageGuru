package com.garbage_guru.api.service.dustbin;

import java.util.List;

import com.garbage_guru.api.dto.DustbinDto;
import com.garbage_guru.api.entity.Dustbin;


public interface IDustbinService {
    Dustbin createDustbin(DustbinDto dustbinDto);

    Dustbin updateDustbin(Long dustbinId, DustbinDto dustbinDto);

    void deleteDustbin(Long dustbinId);

    Dustbin getDustbinById(Long dustbinId);

    List<Dustbin> getAllDustbins();

   Dustbin getDustbinsByNumber(Long dustNo);

    List<Dustbin> getDustbinsByArea(Long areaId);

    List<Dustbin> getDustbinsByCategory(Long categoryId);
}
