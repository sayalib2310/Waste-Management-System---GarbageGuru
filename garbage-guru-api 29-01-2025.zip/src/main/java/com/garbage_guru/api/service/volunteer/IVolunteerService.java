package com.garbage_guru.api.service.volunteer;

import java.util.List;
import java.util.Optional;

import com.garbage_guru.api.entity.Volunteer;
import com.garbage_guru.api.request.CreateVolunteerRequest;

public interface IVolunteerService {
  Volunteer createVolunteer(CreateVolunteerRequest request);

    Volunteer updateVolunteer(Long volunteerId, Volunteer request);

    Optional<Volunteer> getVolunteerById(Long volunteerId);

    List<Volunteer> getAllVolunteers();

    void deleteVolunteer(Long volunteerId);

    Volunteer enrollInEvent(Long volunteerId, Long eventId);
}
