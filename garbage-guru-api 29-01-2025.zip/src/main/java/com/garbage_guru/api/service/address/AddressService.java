package com.garbage_guru.api.service.address;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.garbage_guru.api.entity.Address;
import com.garbage_guru.api.repository.AddressRepository;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class AddressService implements IAddressService {
    private final AddressRepository addressRepository;

    public Address saveAddress(Address address) {
          return addressRepository.save(address);
    }

    // Retrieve all Addresses
    public List<Address> getAllAddresses() {
          return addressRepository.findAll();
    }

    // Retrieve Address by ID
    public Optional<Address> getAddressById(Long id) {
          return addressRepository.findById(id);
    }

    // Delete Address by ID
    public void deleteAddressById(Long id) {
          addressRepository.deleteById(id);
    }
}