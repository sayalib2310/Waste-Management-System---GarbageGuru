package com.garbage_guru.api.service.address;

import java.util.List;
import java.util.Optional;

import com.garbage_guru.api.entity.Address;

public interface IAddressService {
    public Address saveAddress(Address address) ;

    // Retrieve all Addresses
    public List<Address> getAllAddresses() ;

    // Retrieve Address by ID
    public Optional<Address> getAddressById(Long id) ;

    // Delete Address by ID
    public void deleteAddressById(Long id) ;
}
