package com.garbage_guru.api.service.complaint;

import java.util.List;

import com.garbage_guru.api.entity.Complaint;
import com.garbage_guru.api.enums.ComplaintStatus;
import com.garbage_guru.api.request.CreateComplaintRequest;

public interface IComplaintService {
    Complaint createComplaint(CreateComplaintRequest request);

    Complaint changeStatus(Long complaintId, ComplaintStatus status);

    Complaint getComplaintById(Long complaintId);

    List<Complaint> getComplaintsByUserId(Long userId);

    void deleteComplaint(Long complaintId);
    
    List<Complaint> getAllComplaints();

}
