package com.garbage_guru.api.service.user;

import java.util.HashMap;
import java.util.List;

import com.garbage_guru.api.dto.UserDto;
import com.garbage_guru.api.entity.User;


public interface IUserService {
    User createUser(User user);
    User updateUser(Long userId, User user);
    void deleteUser(Long userId);
    User getUserById(Long userId);
    List<User> getAllUsers();
    UserDto login(String userName, String password);
    User adminLogin(String userName, String password);
    HashMap<String,Object> getAddressCategoryStatus();
}
