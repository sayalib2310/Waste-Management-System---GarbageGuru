package com.garbage_guru.api.service.complaint;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.garbage_guru.api.entity.Address;
import com.garbage_guru.api.entity.Complaint;
import com.garbage_guru.api.entity.Dustbin;
import com.garbage_guru.api.entity.User;
import com.garbage_guru.api.enums.ComplaintStatus;
import com.garbage_guru.api.repository.ComplaintRepository;
import com.garbage_guru.api.request.CreateComplaintRequest;
import com.garbage_guru.api.service.address.AddressService;
import com.garbage_guru.api.service.dustbin.DustbinService;
import com.garbage_guru.api.service.user.UserService;

import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Transactional
@RequiredArgsConstructor
@Service
public class ComplaintService implements IComplaintService {

    private final ComplaintRepository complaintRepository;
    private final UserService userService; // Service to fetch User
    private final DustbinService dustbinService; // Service to fetch Dustbin
    private final AddressService addressService;

    @Override
    public Complaint createComplaint(CreateComplaintRequest request) {
        User user = userService.getUserById(request.getUserId());
        Dustbin dustbin = dustbinService.getDustbinsByNumber(request.getDustbinNo());
        Address area = addressService.getAddressById(request.getAreaId()).get();

        Complaint complaint = new Complaint();
        complaint.setUser(user);
        complaint.setDustbin(dustbin);
        complaint.setArea(area);
        complaint.setAddress(request.getAddress());
        complaint.setIssue(request.getIssue());
        complaint.setCreatedAt(request.getCreatedAt() != null ? request.getCreatedAt() : new Date());
        complaint.setStatus(ComplaintStatus.OPEN);

        return complaintRepository.save(complaint);
    }

    @Override
    public Complaint changeStatus(Long complaintId, ComplaintStatus status) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new EntityNotFoundException("Complaint not found with ID: " + complaintId));

        complaint.setStatus(status);
        return complaintRepository.save(complaint);
    }

    @Override
    public Complaint getComplaintById(Long complaintId) {
        return complaintRepository.findById(complaintId)
                .orElseThrow(() -> new EntityNotFoundException("Complaint not found with ID: " + complaintId));
    }

    @Override
    public List<Complaint> getComplaintsByUserId(Long userId) {
        User user = userService.getUserById(userId);
        return complaintRepository.findByUser(user);
    }

    @Override
    public void deleteComplaint(Long complaintId) {
        if (!complaintRepository.existsById(complaintId)) {
            throw new EntityNotFoundException("Complaint not found with ID: " + complaintId);
        }
        complaintRepository.deleteById(complaintId);
    }

    @Override
    public List<Complaint> getAllComplaints() {
        return complaintRepository.findAll();
    }

}
