package com.garbage_guru.api.service.volunteer;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.garbage_guru.api.entity.Event;
import com.garbage_guru.api.entity.User;
import com.garbage_guru.api.entity.Volunteer;
import com.garbage_guru.api.exception.ResourceInvalidException;
import com.garbage_guru.api.repository.EventRepository;
import com.garbage_guru.api.repository.VolunteerRepository;
import com.garbage_guru.api.request.CreateVolunteerRequest;
import com.garbage_guru.api.service.user.IUserService;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class VolunteerService implements IVolunteerService {

    private final VolunteerRepository volunteerRepository;
    private final EventRepository eventRepository;
    private final IUserService userService;
    private final ModelMapper modelMapper;

    @Override
    public Volunteer createVolunteer(CreateVolunteerRequest request) {
        Volunteer volunteer = modelMapper.map(request, Volunteer.class);
        volunteer.setVolunteerId(null);
        User user = userService.getUserById(request.getUserId());
        volunteer.setUser(user);

        return volunteerRepository.save(volunteer);
    }

    @Override
    public Volunteer updateVolunteer(Long volunteerId, Volunteer volunteer) {
        if (!volunteerRepository.existsById(volunteerId)) {
            throw new IllegalArgumentException("Volunteer with id " + volunteerId + " does not exist");
        }
        volunteer.setVolunteerId(volunteerId);
        return volunteerRepository.save(volunteer);
    }

    @Override
    public Optional<Volunteer> getVolunteerById(Long volunteerId) {
        return volunteerRepository.findById(volunteerId);
    }

    @Override
    public List<Volunteer> getAllVolunteers() {
        return volunteerRepository.findAll();
    }

    @Transactional
    @Override
    public void deleteVolunteer(Long volunteerId) {

        Volunteer volunteer = volunteerRepository.findById(volunteerId)
                .orElseThrow(() -> new RuntimeException("Volunteer with id " + volunteerId +
                        " does not exist"));

        for (Event event : volunteer.getEvents()) {
            event.getVolunteers().remove(volunteer);
        }
        volunteer.getEvents().clear();

        volunteerRepository.delete(volunteer);

    }

    @Override
    public Volunteer enrollInEvent(Long volunteerId, Long eventId) {
        Volunteer volunteer = volunteerRepository.findById(volunteerId)
                .orElseThrow(
                        () -> new IllegalArgumentException("Volunteer with id " + volunteerId + " does not exist"));

        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new IllegalArgumentException("Event with id " + eventId + " does not exist"));

        if (event.getMaxParticipants() > event.getVolunteers().size()) {
            event.getVolunteers().add(volunteer);

            eventRepository.save(event);

            return volunteer;
        } else {
            throw new ResourceInvalidException("Reach to max Participants");
        }

    }

}
