package com.garbage_guru.api.service.user;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.garbage_guru.api.dto.UserDto;
import com.garbage_guru.api.entity.User;
import com.garbage_guru.api.entity.Volunteer;
import com.garbage_guru.api.exception.ResourceInvalidException;
import com.garbage_guru.api.exception.ResourceNotFoundException;
import com.garbage_guru.api.repository.AddressRepository;
import com.garbage_guru.api.repository.CategoryRepository;
import com.garbage_guru.api.repository.DustbinRepository;
import com.garbage_guru.api.repository.StatusRepository;
import com.garbage_guru.api.repository.UserRepository;
import com.garbage_guru.api.repository.VolunteerRepository;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserService implements IUserService {

    private final UserRepository userRepository;
    final CategoryRepository categoryRepository;
    final StatusRepository statusRepository;
    final AddressRepository addressRepository;
    final DustbinRepository dustbinRepository;
    final VolunteerRepository volunteerRepository;
    final ModelMapper modelMapper;

    @Override
    public User createUser(User user) {
        return userRepository.save(user);
    }

    @Override
    public User updateUser(Long userId, User user) {
        Optional<User> existingUser = userRepository.findById(userId);
        if (existingUser.isPresent()) {
            User updatedUser = existingUser.get();
            updatedUser.setFirstName(user.getFirstName());
            updatedUser.setLastName(user.getLastName());
            updatedUser.setUserName(user.getUserName());
            updatedUser.setEmailId(user.getEmailId());
            updatedUser.setPassword(user.getPassword());
            updatedUser.setContactNo(user.getContactNo());
            updatedUser.setAadharNo(user.getAadharNo());
            updatedUser.setAddress(user.getAddress());
            updatedUser.setArea(user.getArea());
            return userRepository.save(updatedUser);
        }
        throw new ResourceNotFoundException("User not found with ID: " + userId);
    }

    @Transactional
    @Override
    public void deleteUser(Long userId) {

        userRepository.deleteById(userId);
    }

    @Override
    public User getUserById(Long userId) {

        return userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with ID: " + userId));
    }

    @Override
    public List<User> getAllUsers() {
        return userRepository.findByRoleRoleId(1L);
    }

    @Override
    public UserDto login(String userName, String password) {
        Optional<User> user = userRepository.findByUserName(userName);
        if (user.isPresent()) {
            if (user.get().getPassword().equals(password)) {
                UserDto userDto = modelMapper.map(user.get(), UserDto.class);

                Optional<Volunteer> optionalVolunteer = volunteerRepository.findByUserUserId(user.get().getUserId());

                return optionalVolunteer.map(volunteer -> {
                    userDto.setVolunteerId(volunteer.getVolunteerId());
                    userDto.setVolunteer(true);
                    return userDto;
                }).orElseGet(() -> {
                    userDto.setVolunteer(false);
                    return userDto;
                });

            }
            throw new ResourceInvalidException("Invalid password");
        }
        throw new ResourceNotFoundException("User not found with username: " + userName);
    }

    @Override
    public User adminLogin(String userName, String password) {
        Optional<User> user = userRepository.findByUserName(userName);
        if (user.isPresent()) {
            User foundUser = user.get();
            // Check password and role
            if (foundUser.getPassword().equals(password)
                    && "ROLE_ADMIN".equalsIgnoreCase(foundUser.getRole().getRoleName())) {
                return foundUser;
            }
            throw new ResourceInvalidException("Unauthorized: User is not an admin or invalid credentials.");
        }
        throw new ResourceNotFoundException("User not found with username: " + userName);
    }

    @Override
    public HashMap<String, Object> getAddressCategoryStatus() {
        HashMap<String, Object> hashMap = new HashMap<>();
        hashMap.put("category", categoryRepository.findAll());
        hashMap.put("address", addressRepository.findAll());
        hashMap.put("status", statusRepository.findAll());

        return hashMap;
    }

}
