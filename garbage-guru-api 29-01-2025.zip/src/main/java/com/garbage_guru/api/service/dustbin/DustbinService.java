package com.garbage_guru.api.service.dustbin;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.garbage_guru.api.dto.DustbinDto;
import com.garbage_guru.api.entity.Dustbin;
import com.garbage_guru.api.entity.Status;
import com.garbage_guru.api.exception.ResourceNotFoundException;
import com.garbage_guru.api.repository.AddressRepository;
import com.garbage_guru.api.repository.CategoryRepository;
import com.garbage_guru.api.repository.DustbinRepository;
import com.garbage_guru.api.repository.StatusRepository;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class DustbinService implements IDustbinService {
    private final DustbinRepository dustbinRepository;
    private final StatusRepository statusRepository;
    private final AddressRepository addressRepository;
    private final CategoryRepository categoryRepository;

    @Override
    public Dustbin createDustbin(DustbinDto dustbinDto) {
        Dustbin dustbin = new Dustbin();
        dustbin.setAllocatedDate(dustbinDto.getAllocatedDate());
        dustbin.setLastCleanDate(dustbinDto.getLastCleanDate());
        dustbin.setGarbageQtyInKg(dustbinDto.getGarbageQtyInKg());
        Status status = statusRepository.findById(dustbinDto.getStatusId()).get();
        dustbin.setStatus(status);

        dustbin.setArea(addressRepository.findById(dustbinDto.getAreaId()).get());
        dustbin.setCategory(categoryRepository.findById(dustbinDto.getCategoryId()).get());
        dustbin.setDustNo(dustbinDto.getDustNo());
        return dustbinRepository.save(dustbin);
    }

    @Override
    public Dustbin updateDustbin(Long dustbinId, DustbinDto dustbinDto) {
        Optional<Dustbin> existingDustbin = dustbinRepository.findById(dustbinId);
        if (existingDustbin.isPresent()) {
            Dustbin updatedDustbin = existingDustbin.get();
            updatedDustbin.setAllocatedDate(dustbinDto.getAllocatedDate());
            updatedDustbin.setLastCleanDate(dustbinDto.getLastCleanDate());
            updatedDustbin.setGarbageQtyInKg(dustbinDto.getGarbageQtyInKg());
            Status status = statusRepository.findById(dustbinDto.getStatusId()).get();
            updatedDustbin.setStatus(status);

            updatedDustbin.setArea(addressRepository.findById(dustbinDto.getAreaId()).get());
           
            updatedDustbin.setCategory(categoryRepository.findById(dustbinDto.getCategoryId()).get());
            updatedDustbin.setDustNo(dustbinDto.getDustNo());
            return dustbinRepository.save(updatedDustbin);
        }
        throw new ResourceNotFoundException("Dustbin not found with ID: " + dustbinId);
    }

    @Override
    public void deleteDustbin(Long dustbinId) {
        dustbinRepository.deleteById(dustbinId);
    }

    @Override
    public Dustbin getDustbinById(Long dustbinId) {
        return dustbinRepository.findById(dustbinId)
                .orElseThrow(() -> new RuntimeException("Dustbin not found with ID: " + dustbinId));
    }

    @Override
    public List<Dustbin> getAllDustbins() {
        return dustbinRepository.findAll();
    }

    @Override
    public Dustbin getDustbinsByNumber(Long dustNo) {
        return dustbinRepository.findByDustNo(dustNo);
    }

    @Override
    public List<Dustbin> getDustbinsByArea(Long areaId) {
        return dustbinRepository.findByArea_AreaId(areaId);
    }

    @Override
    public List<Dustbin> getDustbinsByCategory(Long categoryId) {
        return dustbinRepository.findByCategory_CategoryId(categoryId);
    }
}
