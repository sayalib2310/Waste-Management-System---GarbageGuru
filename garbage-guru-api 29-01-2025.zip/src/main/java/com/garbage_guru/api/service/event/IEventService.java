package com.garbage_guru.api.service.event;

import java.util.List;
import java.util.Optional;

import com.garbage_guru.api.dto.EventDto;
import com.garbage_guru.api.dto.VolunteerDto;
import com.garbage_guru.api.entity.Event;
import com.garbage_guru.api.request.CreateEventRequest;

public interface IEventService {
    Event createEvent(CreateEventRequest event);

    Event updateEvent(Long eventId, CreateEventRequest event);

    Optional<Event> getEventById(Long eventId);

    List<Event> getAllEvents();

    void deleteEvent(Long eventId);

    void removeVolunteerFromEvent(Long eventId, Long volunteerId);

    public List<EventDto> getEventsByVolunteerId(Long volunteerId);
    public List<VolunteerDto> getVolunteersByEventId(Long eventId);

}
