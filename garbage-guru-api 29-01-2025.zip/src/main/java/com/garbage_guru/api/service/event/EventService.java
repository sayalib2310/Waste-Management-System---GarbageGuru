package com.garbage_guru.api.service.event;

import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

import com.garbage_guru.api.dto.EventDto;
import com.garbage_guru.api.dto.VolunteerDto;
import com.garbage_guru.api.entity.Event;
import com.garbage_guru.api.entity.User;
import com.garbage_guru.api.entity.Volunteer;
import com.garbage_guru.api.exception.ResourceNotFoundException;
import com.garbage_guru.api.repository.EventEnrollmentsRepository;
import com.garbage_guru.api.repository.EventRepository;
import com.garbage_guru.api.request.CreateEventRequest;
import com.garbage_guru.api.service.address.IAddressService;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class EventService implements IEventService {
    private final EventRepository eventRepository;
    private final EventEnrollmentsRepository eventEnrollmentsRepository;
    private final IAddressService addressService;

    @Override
    public Event createEvent(CreateEventRequest event) {
        Event newEvent = new Event();
        newEvent.setEventName(event.getEventName());
        newEvent.setDescription(event.getDescription());
        newEvent.setEventDate(event.getEventDate());
        newEvent.setMaxParticipants(event.getMaxParticipants());
        newEvent.setArea(addressService.getAddressById(event.getAreaId()).get());
        return eventRepository.save(newEvent);
    }

    @Override
    public Event updateEvent(Long eventId, CreateEventRequest request) {
        if (!eventRepository.existsById(eventId)) {
            throw new IllegalArgumentException("Event with id " + eventId + " does not exist");
        }

        return eventRepository.findById(eventId).map((event) -> {
            event.setEventName(request.getEventName());
            event.setDescription(request.getDescription());
            event.setEventDate(request.getEventDate());
            event.setMaxParticipants(request.getMaxParticipants());
            event.setArea(addressService.getAddressById(request.getAreaId()).get());
            return event;
        }).map(eventRepository::save).orElseThrow(() -> new ResourceNotFoundException("Invalid Event Id"));

    }

    @Override
    public Optional<Event> getEventById(Long eventId) {
        return eventRepository.findById(eventId);
    }

    @Override
    public List<Event> getAllEvents() {
        return eventRepository.findAll();
    }

    @Override
    public void deleteEvent(Long eventId) {
        if (!eventRepository.existsById(eventId)) {
            throw new IllegalArgumentException("Event with id " + eventId + " does not exist");
        }
        eventRepository.deleteById(eventId);
    }

    @Override
    public void removeVolunteerFromEvent(Long eventId, Long volunteerId) {
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new IllegalArgumentException("Event with id " + eventId + " does not exist"));

        Volunteer volunteerToRemove = event.getVolunteers().stream()
                .filter(volunteer -> volunteer.getVolunteerId().equals(volunteerId))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException(
                        "Volunteer with id " + volunteerId + " is not enrolled in this event"));

        event.getVolunteers().remove(volunteerToRemove);
        eventRepository.save(event);
    }

    @Override
    public List<EventDto> getEventsByVolunteerId(Long volunteerId) {
        List<Event> events = eventRepository.findEventsByVolunteersVolunteerId(volunteerId);
        return events.stream().map(this::convertToDto).toList();
    }

    // Get Event Enrollments by Event ID
    @Override
    public List<VolunteerDto> getVolunteersByEventId(Long eventId) {
        List<Volunteer> volunteers = eventEnrollmentsRepository.findVolunteersByEventId(eventId);
        return volunteers.stream().map(this::convertToVolunteerDto).toList();
    }

    // Convert Event entity to DTO
    private EventDto convertToDto(Event event) {
        EventDto dto = new EventDto();
        dto.setEventId(event.getEventId());
        dto.setEventName(event.getEventName());
        dto.setDescription(event.getDescription());
        dto.setEventDate(event.getEventDate());
        dto.setMaxParticipants(event.getMaxParticipants());
        int rem = event.getMaxParticipants() - event.getVolunteers().size();
        dto.setRemainingParticipants(rem);
        dto.setArea(event.getArea());
        return dto;
    }

    // Convert Volunteer entity to DTO
    private VolunteerDto convertToVolunteerDto(Volunteer volunteer) {
        VolunteerDto dto = new VolunteerDto();
        dto.setVolunteerId(volunteer.getVolunteerId());
        dto.setDepartment(volunteer.getDepartment());
        dto.setPurpose(volunteer.getPurpose());
        dto.setExperience(volunteer.getExperience());

        User user = volunteer.getUser();
        if (user != null) {
            dto.setUserId(user.getUserId());
            dto.setFirstName(user.getFirstName());
            dto.setLastName(user.getLastName());
            dto.setUserName(user.getUserName());
            dto.setEmailId(user.getEmailId());
            dto.setContactNo(user.getContactNo());
            dto.setAadharNo(user.getAadharNo());
            dto.setArea(user.getArea());
            dto.setAddress(user.getAddress());
        }

        return dto;
    }

}
